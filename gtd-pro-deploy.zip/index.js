var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// drizzle/schema.ts
var schema_exports = {};
__export(schema_exports, {
  attachments: () => attachments,
  attendance: () => attendance,
  auditLogs: () => auditLogs,
  boq: () => boq,
  changeOrders: () => changeOrders,
  clients: () => clients,
  companySettings: () => companySettings,
  drawingVersions: () => drawingVersions,
  drawings: () => drawings,
  employees: () => employees,
  expenses: () => expenses,
  forms: () => forms,
  installments: () => installments,
  invoiceItems: () => invoiceItems,
  invoices: () => invoices,
  leaves: () => leaves,
  payroll: () => payroll,
  performanceReviews: () => performanceReviews,
  projectTasks: () => projectTasks,
  projects: () => projects,
  purchases: () => purchases,
  rfis: () => rfis,
  sales: () => sales,
  submittals: () => submittals,
  taskComments: () => taskComments,
  userPermissions: () => userPermissions,
  users: () => users
});
import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, index } from "drizzle-orm/mysql-core";
var users, clients, projects, invoices, invoiceItems, forms, boq, expenses, installments, auditLogs, companySettings, attachments, userPermissions, projectTasks, taskComments, employees, attendance, payroll, leaves, performanceReviews, sales, purchases, changeOrders, rfis, submittals, drawings, drawingVersions;
var init_schema = __esm({
  "drizzle/schema.ts"() {
    "use strict";
    users = mysqlTable("users", {
      id: int("id").autoincrement().primaryKey(),
      openId: varchar("openId", { length: 64 }).notNull().unique(),
      name: text("name"),
      email: varchar("email", { length: 320 }),
      loginMethod: varchar("loginMethod", { length: 64 }),
      role: mysqlEnum("role", [
        "admin",
        "accountant",
        "finance_manager",
        "project_manager",
        "site_engineer",
        "planning_engineer",
        "procurement_officer",
        "qa_qc",
        "document_controller",
        "architect",
        "interior_designer",
        "sales_manager",
        "hr_manager",
        "storekeeper",
        "designer",
        "viewer"
      ]).default("designer").notNull(),
      isActive: boolean("isActive").default(true).notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
      lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
    });
    clients = mysqlTable("clients", {
      id: int("id").autoincrement().primaryKey(),
      clientNumber: varchar("clientNumber", { length: 50 }).notNull().unique(),
      name: varchar("name", { length: 255 }).notNull(),
      email: varchar("email", { length: 320 }),
      phone: varchar("phone", { length: 50 }),
      address: text("address"),
      city: varchar("city", { length: 100 }),
      notes: text("notes"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    projects = mysqlTable("projects", {
      id: int("id").autoincrement().primaryKey(),
      projectNumber: varchar("projectNumber", { length: 50 }).notNull().unique(),
      clientId: int("clientId").notNull(),
      name: varchar("name", { length: 255 }).notNull(),
      description: text("description"),
      status: mysqlEnum("status", ["design", "execution", "delivery", "completed", "cancelled"]).default("design").notNull(),
      startDate: timestamp("startDate"),
      endDate: timestamp("endDate"),
      budget: int("budget"),
      assignedTo: int("assignedTo"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    invoices = mysqlTable("invoices", {
      id: int("id").autoincrement().primaryKey(),
      invoiceNumber: varchar("invoiceNumber", { length: 50 }).notNull().unique(),
      type: mysqlEnum("type", ["invoice", "quote"]).notNull(),
      clientId: int("clientId").notNull(),
      projectId: int("projectId"),
      issueDate: timestamp("issueDate").notNull(),
      dueDate: timestamp("dueDate"),
      status: mysqlEnum("status", ["draft", "sent", "paid", "cancelled"]).default("draft").notNull(),
      subtotal: int("subtotal").notNull(),
      tax: int("tax").default(0),
      discount: int("discount").default(0),
      total: int("total").notNull(),
      notes: text("notes"),
      terms: text("terms"),
      formData: text("formData"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      idx_issueDate: index("idx_invoices_issueDate").on(t2.issueDate),
      idx_client: index("idx_invoices_clientId").on(t2.clientId),
      idx_project: index("idx_invoices_projectId").on(t2.projectId)
    }));
    invoiceItems = mysqlTable("invoiceItems", {
      id: int("id").autoincrement().primaryKey(),
      invoiceId: int("invoiceId").notNull(),
      description: text("description").notNull(),
      quantity: int("quantity").notNull(),
      unitPrice: int("unitPrice").notNull(),
      total: int("total").notNull(),
      sortOrder: int("sortOrder").default(0)
    });
    forms = mysqlTable("forms", {
      id: int("id").autoincrement().primaryKey(),
      formNumber: varchar("formNumber", { length: 50 }).notNull().unique(),
      clientId: int("clientId").notNull(),
      projectId: int("projectId"),
      formType: varchar("formType", { length: 100 }).notNull(),
      formData: text("formData").notNull(),
      status: mysqlEnum("status", ["pending", "reviewed", "approved", "rejected"]).default("pending").notNull(),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    boq = mysqlTable("boq", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      itemName: varchar("itemName", { length: 255 }).notNull(),
      description: text("description"),
      quantity: int("quantity").notNull(),
      unit: varchar("unit", { length: 50 }),
      unitPrice: int("unitPrice").notNull(),
      total: int("total").notNull(),
      category: varchar("category", { length: 100 }),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    expenses = mysqlTable("expenses", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId"),
      category: varchar("category", { length: 100 }).notNull(),
      description: text("description").notNull(),
      amount: int("amount").notNull(),
      expenseDate: timestamp("expenseDate").notNull(),
      receipt: varchar("receipt", { length: 500 }),
      status: mysqlEnum("status", ["active", "cancelled"]).default("active").notNull(),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      idx_expenseDate: index("idx_expenses_expenseDate").on(t2.expenseDate),
      idx_project: index("idx_expenses_projectId").on(t2.projectId)
    }));
    installments = mysqlTable("installments", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      invoiceId: int("invoiceId"),
      installmentNumber: int("installmentNumber").notNull(),
      amount: int("amount").notNull(),
      dueDate: timestamp("dueDate").notNull(),
      paidDate: timestamp("paidDate"),
      status: mysqlEnum("status", ["pending", "paid", "overdue", "cancelled"]).default("pending").notNull(),
      paymentMethod: varchar("paymentMethod", { length: 50 }),
      notes: text("notes"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      idx_createdAt: index("idx_installments_createdAt").on(t2.createdAt),
      idx_project: index("idx_installments_projectId").on(t2.projectId),
      idx_invoice: index("idx_installments_invoiceId").on(t2.invoiceId)
    }));
    auditLogs = mysqlTable("auditLogs", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull(),
      action: varchar("action", { length: 100 }).notNull(),
      entityType: varchar("entityType", { length: 50 }),
      entityId: int("entityId"),
      details: text("details"),
      ipAddress: varchar("ipAddress", { length: 45 }),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    }, (t2) => ({
      idx_createdAt: index("idx_auditLogs_createdAt").on(t2.createdAt),
      idx_entity: index("idx_auditLogs_entity").on(t2.entityType, t2.entityId)
    }));
    companySettings = mysqlTable("companySettings", {
      id: int("id").autoincrement().primaryKey(),
      settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
      settingValue: text("settingValue"),
      updatedBy: int("updatedBy"),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    attachments = mysqlTable("attachments", {
      id: int("id").autoincrement().primaryKey(),
      entityType: varchar("entityType", { length: 50 }).notNull(),
      entityId: int("entityId").notNull(),
      fileName: varchar("fileName", { length: 255 }).notNull(),
      fileKey: varchar("fileKey", { length: 500 }).notNull(),
      fileUrl: varchar("fileUrl", { length: 1e3 }).notNull(),
      fileSize: int("fileSize"),
      mimeType: varchar("mimeType", { length: 100 }),
      uploadedBy: int("uploadedBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    userPermissions = mysqlTable("userPermissions", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull().unique(),
      permissionsJson: text("permissionsJson"),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    projectTasks = mysqlTable("projectTasks", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      name: varchar("name", { length: 255 }).notNull(),
      description: text("description"),
      startDate: timestamp("startDate"),
      endDate: timestamp("endDate"),
      status: mysqlEnum("status", ["planned", "in_progress", "done", "cancelled"]).default("planned").notNull(),
      assignedTo: int("assignedTo"),
      priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
      estimateHours: int("estimateHours"),
      progress: int("progress").default(0).notNull(),
      parentId: int("parentId"),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      idx_project: index("idx_projectTasks_projectId").on(t2.projectId),
      idx_assignedTo: index("idx_projectTasks_assignedTo").on(t2.assignedTo),
      idx_parentId: index("idx_projectTasks_parentId").on(t2.parentId)
    }));
    taskComments = mysqlTable("taskComments", {
      id: int("id").autoincrement().primaryKey(),
      taskId: int("taskId").notNull(),
      content: text("content").notNull(),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    employees = mysqlTable("employees", {
      id: int("id").autoincrement().primaryKey(),
      userId: int("userId").notNull().unique(),
      employeeNumber: varchar("employeeNumber", { length: 50 }).notNull().unique(),
      department: varchar("department", { length: 100 }),
      position: varchar("position", { length: 100 }),
      hireDate: timestamp("hireDate").notNull(),
      salary: int("salary"),
      bankAccount: varchar("bankAccount", { length: 100 }),
      emergencyContact: text("emergencyContact"),
      status: mysqlEnum("status", ["active", "on_leave", "terminated"]).default("active").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    attendance = mysqlTable("attendance", {
      id: int("id").autoincrement().primaryKey(),
      employeeId: int("employeeId").notNull(),
      date: timestamp("date").notNull(),
      checkIn: timestamp("checkIn"),
      checkOut: timestamp("checkOut"),
      hoursWorked: int("hoursWorked"),
      status: mysqlEnum("status", ["present", "absent", "late", "half_day"]).default("present").notNull(),
      notes: text("notes"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    payroll = mysqlTable("payroll", {
      id: int("id").autoincrement().primaryKey(),
      employeeId: int("employeeId").notNull(),
      month: int("month").notNull(),
      year: int("year").notNull(),
      baseSalary: int("baseSalary").notNull(),
      bonuses: int("bonuses").default(0),
      deductions: int("deductions").default(0),
      netSalary: int("netSalary").notNull(),
      paymentDate: timestamp("paymentDate"),
      status: mysqlEnum("status", ["pending", "paid"]).default("pending").notNull(),
      notes: text("notes"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    leaves = mysqlTable("leaves", {
      id: int("id").autoincrement().primaryKey(),
      employeeId: int("employeeId").notNull(),
      leaveType: mysqlEnum("leaveType", ["annual", "sick", "emergency", "unpaid"]).notNull(),
      startDate: timestamp("startDate").notNull(),
      endDate: timestamp("endDate").notNull(),
      days: int("days").notNull(),
      reason: text("reason"),
      status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
      approvedBy: int("approvedBy"),
      approvedAt: timestamp("approvedAt"),
      notes: text("notes"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    performanceReviews = mysqlTable("performanceReviews", {
      id: int("id").autoincrement().primaryKey(),
      employeeId: int("employeeId").notNull(),
      reviewerId: int("reviewerId").notNull(),
      reviewDate: timestamp("reviewDate").notNull(),
      period: varchar("period", { length: 50 }),
      rating: int("rating"),
      strengths: text("strengths"),
      weaknesses: text("weaknesses"),
      goals: text("goals"),
      comments: text("comments"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    sales = mysqlTable("sales", {
      id: int("id").autoincrement().primaryKey(),
      saleNumber: varchar("saleNumber", { length: 50 }).notNull().unique(),
      clientId: int("clientId").notNull(),
      projectId: int("projectId"),
      description: text("description").notNull(),
      amount: int("amount").notNull(),
      paymentMethod: mysqlEnum("paymentMethod", ["cash", "bank_transfer", "check", "credit"]).default("cash").notNull(),
      saleDate: timestamp("saleDate").notNull(),
      status: mysqlEnum("status", ["pending", "completed", "cancelled"]).default("pending").notNull(),
      invoiceId: int("invoiceId"),
      notes: text("notes"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    purchases = mysqlTable("purchases", {
      id: int("id").autoincrement().primaryKey(),
      purchaseNumber: varchar("purchaseNumber", { length: 50 }).notNull().unique(),
      supplierId: int("supplierId"),
      supplierName: varchar("supplierName", { length: 255 }).notNull(),
      projectId: int("projectId"),
      description: text("description").notNull(),
      amount: int("amount").notNull(),
      paymentMethod: mysqlEnum("paymentMethod", ["cash", "bank_transfer", "check", "credit"]).default("cash").notNull(),
      purchaseDate: timestamp("purchaseDate").notNull(),
      status: mysqlEnum("status", ["pending", "completed", "cancelled"]).default("pending").notNull(),
      category: varchar("category", { length: 100 }),
      notes: text("notes"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    }, (t2) => ({
      idx_purchaseDate: index("idx_purchases_purchaseDate").on(t2.purchaseDate),
      idx_project: index("idx_purchases_projectId").on(t2.projectId)
    }));
    changeOrders = mysqlTable("changeOrders", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      code: varchar("code", { length: 64 }).notNull().unique(),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description"),
      origin: mysqlEnum("origin", ["client", "internal", "site"]).default("client").notNull(),
      status: mysqlEnum("status", ["draft", "submitted", "approved", "rejected", "cancelled"]).default("draft").notNull(),
      impactCost: int("impactCost").default(0).notNull(),
      impactDays: int("impactDays").default(0).notNull(),
      submittedBy: int("submittedBy"),
      submittedAt: timestamp("submittedAt"),
      approvedBy: int("approvedBy"),
      approvedAt: timestamp("approvedAt"),
      rejectedBy: int("rejectedBy"),
      rejectedAt: timestamp("rejectedAt"),
      rejectionReason: text("rejectionReason"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull(),
      updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
    });
    rfis = mysqlTable("rfis", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      rfiNumber: varchar("rfiNumber", { length: 64 }).notNull().unique(),
      title: varchar("title", { length: 255 }).notNull(),
      question: text("question").notNull(),
      status: mysqlEnum("status", ["open", "answered", "closed"]).default("open").notNull(),
      submittedBy: int("submittedBy").notNull(),
      submittedAt: timestamp("submittedAt").defaultNow().notNull(),
      answeredBy: int("answeredBy"),
      answeredAt: timestamp("answeredAt"),
      answer: text("answer"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    submittals = mysqlTable("submittals", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      submittalCode: varchar("submittalCode", { length: 64 }).notNull().unique(),
      title: varchar("title", { length: 255 }).notNull(),
      status: mysqlEnum("status", ["submitted", "approved", "rejected"]).default("submitted").notNull(),
      submittedBy: int("submittedBy").notNull(),
      submittedAt: timestamp("submittedAt").defaultNow().notNull(),
      approvedBy: int("approvedBy"),
      approvedAt: timestamp("approvedAt"),
      notes: text("notes"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    drawings = mysqlTable("drawings", {
      id: int("id").autoincrement().primaryKey(),
      projectId: int("projectId").notNull(),
      drawingCode: varchar("drawingCode", { length: 64 }).notNull().unique(),
      title: varchar("title", { length: 255 }).notNull(),
      discipline: varchar("discipline", { length: 64 }),
      status: mysqlEnum("status", ["draft", "issued", "approved"]).default("draft").notNull(),
      currentVersionId: int("currentVersionId"),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
    drawingVersions = mysqlTable("drawingVersions", {
      id: int("id").autoincrement().primaryKey(),
      drawingId: int("drawingId").notNull(),
      version: varchar("version", { length: 32 }).notNull(),
      fileUrl: varchar("fileUrl", { length: 1e3 }).notNull(),
      notes: text("notes"),
      createdBy: int("createdBy").notNull(),
      createdAt: timestamp("createdAt").defaultNow().notNull()
    });
  }
});

// server/_core/demoStore.ts
var demoStore_exports = {};
__export(demoStore_exports, {
  filter: () => filter,
  findById: () => findById,
  insert: () => insert,
  list: () => list,
  remove: () => remove,
  update: () => update,
  write: () => write
});
import fs from "fs";
import path from "path";
function ensureDir() {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir);
}
function filePath(name) {
  ensureDir();
  return path.join(dir, `${name}.json`);
}
function read(name) {
  const fp = filePath(name);
  if (!fs.existsSync(fp)) return [];
  try {
    const raw = fs.readFileSync(fp, "utf-8");
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}
function write(name, items) {
  const fp = filePath(name);
  fs.writeFileSync(fp, JSON.stringify(items, null, 2), "utf-8");
}
function nextId(items) {
  const max = items.reduce((m, it) => typeof it.id === "number" && it.id > m ? it.id : m, 0);
  return max + 1;
}
function list(name) {
  return read(name);
}
function insert(name, item) {
  const items = read(name);
  const id = nextId(items);
  const now = /* @__PURE__ */ new Date();
  const rec = { ...item, id, createdAt: item.createdAt ?? now, updatedAt: item.updatedAt ?? now };
  items.push(rec);
  write(name, items);
  return rec;
}
function update(name, id, data) {
  const items = read(name);
  const idx = items.findIndex((it) => it.id === id);
  if (idx === -1) return;
  items[idx] = { ...items[idx], ...data, updatedAt: /* @__PURE__ */ new Date() };
  write(name, items);
}
function remove(name, id) {
  const items = read(name).filter((it) => it.id !== id);
  write(name, items);
}
function findById(name, id) {
  const items = read(name);
  const found = items.find((it) => it.id === id);
  return found ?? null;
}
function filter(name, predicate) {
  return read(name).filter(predicate);
}
var dir;
var init_demoStore = __esm({
  "server/_core/demoStore.ts"() {
    "use strict";
    dir = path.resolve(process.cwd(), ".demo_store");
  }
});

// server/_core/vite-prod.ts
var vite_prod_exports = {};
__export(vite_prod_exports, {
  serveStatic: () => serveStatic
});
import express2 from "express";
import fs3 from "fs";
import path3 from "path";
function serveStatic(app) {
  const distPath = path3.resolve(process.cwd(), "dist", "public");
  if (!fs3.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express2.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}
var init_vite_prod = __esm({
  "server/_core/vite-prod.ts"() {
    "use strict";
  }
});

// server/_core/index.ts
import "dotenv/config";
import { createServer } from "http";

// server/_core/app.ts
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "GT_SESSION";
var ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1e3;
var AXIOS_TIMEOUT_MS = 15e3;
var UNAUTHED_ERR_MSG = "Not authenticated";
var NOT_ADMIN_ERR_MSG = "Admin access required";

// server/db.ts
init_schema();
import { eq, desc, and, or, like, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// server/_core/env.ts
var ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.COOKIE_SECRET ?? process.env.JWT_SECRET ?? "",
  cookieDomain: process.env.COOKIE_DOMAIN ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  webOrigin: process.env.WEB_ORIGIN ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: true,
  forgeApiUrl: process.env.FORGE_API_URL ?? process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.FORGE_API_KEY ?? process.env.BUILT_IN_FORGE_API_KEY ?? "",
  allowAutoProvision: (process.env.ALLOW_AUTO_PROVISION ?? "").toLowerCase() === "true",
  allowedEmailDomain: process.env.ALLOWED_EMAIL_DOMAIN ?? "",
  allowedEmails: process.env.ALLOWED_EMAILS ?? ""
};
if (ENV.isProduction) {
  const missing = [];
  if (!ENV.cookieSecret) missing.push("COOKIE_SECRET or JWT_SECRET");
  if (!ENV.databaseUrl) missing.push("DATABASE_URL");
  if (!ENV.webOrigin) missing.push("WEB_ORIGIN");
  if (missing.length > 0) {
    console.error(`[ENV] Missing required production environment variables: ${missing.join(", ")}`);
  }
}

// server/db.ts
init_demoStore();
init_schema();
init_schema();
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    const existing = filter("users", (u) => u.openId === user.openId);
    if (existing.length > 0) {
      const current = existing[0];
      update("users", current.id, {
        name: user.name ?? current.name ?? null,
        email: user.email ?? current.email ?? null,
        loginMethod: user.loginMethod ?? current.loginMethod ?? null,
        role: user.role ?? current.role ?? null,
        lastSignedIn: user.lastSignedIn ?? /* @__PURE__ */ new Date()
      });
    } else {
      insert("users", {
        openId: user.openId,
        name: user.name ?? null,
        email: user.email ?? null,
        loginMethod: user.loginMethod ?? null,
        role: user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : null),
        lastSignedIn: user.lastSignedIn ?? /* @__PURE__ */ new Date()
      });
    }
    return;
  }
  try {
    const values = {
      openId: user.openId
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== void 0) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = /* @__PURE__ */ new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) {
    const match = filter("users", (u) => u.openId === openId);
    return match.length > 0 ? match[0] : void 0;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(users).orderBy(desc(users.createdAt));
}
async function getUserByEmail(email) {
  const db = await getDb();
  if (!db) {
    const match = filter("users", (u) => (u.email || "").toLowerCase() === email.toLowerCase());
    return match.length > 0 ? match[0] : void 0;
  }
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function createUser(user) {
  const db = await getDb();
  if (!db) {
    const rec = insert("users", {
      openId: `local-${Date.now()}-${Math.random().toString(36).substring(7)}`,
      name: user.name,
      email: user.email,
      role: user.role,
      loginMethod: "email",
      lastSignedIn: /* @__PURE__ */ new Date()
    });
    return rec;
  }
  await db.insert(users).values({
    openId: `local-${Date.now()}-${Math.random().toString(36).substring(7)}`,
    name: user.name,
    email: user.email,
    role: user.role,
    loginMethod: "email",
    lastSignedIn: /* @__PURE__ */ new Date()
  });
  const newUser = await db.select().from(users).where(eq(users.email, user.email)).limit(1);
  return newUser[0];
}
async function updateUser(userId, data) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}
async function updateUserRole(userId, role) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, userId));
}
async function deleteUser(userId) {
  const db = await getDb();
  if (!db) {
    remove("users", userId);
    return;
  }
  await db.delete(users).where(eq(users.id, userId));
}
async function createClient(client) {
  const db = await getDb();
  if (!db) return insert("clients", client);
  const result = await db.insert(clients).values(client);
  return result;
}
async function getAllClients() {
  const db = await getDb();
  if (!db) return list("clients");
  return await db.select().from(clients).orderBy(desc(clients.createdAt));
}
async function getClientById(id) {
  const db = await getDb();
  if (!db) return findById("clients", id);
  const result = await db.select().from(clients).where(eq(clients.id, id)).limit(1);
  return result[0] || null;
}
async function updateClient(id, data) {
  const db = await getDb();
  if (!db) return;
  await db.update(clients).set(data).where(eq(clients.id, id));
}
async function deleteClient(id) {
  const db = await getDb();
  if (!db) return;
  await db.delete(clients).where(eq(clients.id, id));
}
async function getClientProjects(clientId) {
  const db = await getDb();
  if (!db) return filter("projects", (p) => p.clientId === clientId);
  return await db.select().from(projects).where(eq(projects.clientId, clientId)).orderBy(desc(projects.createdAt));
}
async function getClientInvoices(clientId) {
  const db = await getDb();
  if (!db) return filter("invoices", (i) => i.clientId === clientId);
  return await db.select().from(invoices).where(eq(invoices.clientId, clientId)).orderBy(desc(invoices.createdAt));
}
async function getClientForms(clientId) {
  const db = await getDb();
  if (!db) return filter("forms", (f) => f.clientId === clientId);
  return await db.select().from(forms).where(eq(forms.clientId, clientId)).orderBy(desc(forms.createdAt));
}
async function createProject(project) {
  const db = await getDb();
  if (!db) return insert("projects", project);
  const result = await db.insert(projects).values(project);
  return result;
}
async function getAllProjects() {
  const db = await getDb();
  if (!db) return list("projects");
  return await db.select().from(projects).orderBy(desc(projects.createdAt));
}
async function getProjectById(id) {
  const db = await getDb();
  if (!db) return findById("projects", id);
  const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  return result[0] || null;
}
async function updateProject(id, data) {
  const db = await getDb();
  if (!db) return;
  await db.update(projects).set(data).where(eq(projects.id, id));
}
async function deleteProject(id) {
  const db = await getDb();
  if (!db) {
    remove("projects", id);
    return;
  }
  await db.delete(boq).where(eq(boq.projectId, id));
  await db.delete(expenses).where(eq(expenses.projectId, id));
  await db.delete(installments).where(eq(installments.projectId, id));
  await db.delete(projects).where(eq(projects.id, id));
}
async function createInvoice(invoice) {
  const db = await getDb();
  if (!db) return insert("invoices", invoice);
  const result = await db.insert(invoices).values(invoice);
  return result;
}
async function getAllInvoices() {
  const db = await getDb();
  if (!db) return list("invoices");
  return await db.select().from(invoices).orderBy(desc(invoices.createdAt));
}
async function getInvoiceById(id) {
  const db = await getDb();
  if (!db) return findById("invoices", id);
  const result = await db.select().from(invoices).where(eq(invoices.id, id)).limit(1);
  return result[0] || null;
}
async function updateInvoice(id, data) {
  const db = await getDb();
  if (!db) return;
  await db.update(invoices).set(data).where(eq(invoices.id, id));
}
async function deleteInvoice(id) {
  const db = await getDb();
  if (!db) return;
  await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, id));
  await db.delete(invoices).where(eq(invoices.id, id));
}
async function getInvoiceItems(invoiceId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId)).orderBy(invoiceItems.sortOrder);
}
async function createInvoiceItem(item) {
  const db = await getDb();
  if (!db) return insert("invoiceItems", item);
  const result = await db.insert(invoiceItems).values(item);
  return result;
}
async function createForm(form) {
  const db = await getDb();
  if (!db) return insert("forms", form);
  const result = await db.insert(forms).values(form);
  return result;
}
async function getAllForms() {
  const db = await getDb();
  if (!db) return list("forms");
  return await db.select().from(forms).orderBy(desc(forms.createdAt));
}
async function getFormById(id) {
  const db = await getDb();
  if (!db) return findById("forms", id);
  const result = await db.select().from(forms).where(eq(forms.id, id)).limit(1);
  return result[0] || null;
}
async function updateForm(id, data) {
  const db = await getDb();
  if (!db) return;
  await db.update(forms).set(data).where(eq(forms.id, id));
}
async function deleteForm(id) {
  const db = await getDb();
  if (!db) {
    remove("forms", id);
    write("attachments", list("attachments").filter((a) => !(a.entityType === "form" && a.entityId === id)));
    return;
  }
  await db.delete(attachments).where(and(eq(attachments.entityType, "form"), eq(attachments.entityId, id)));
  await db.delete(forms).where(eq(forms.id, id));
}
async function getProjectBOQ(projectId) {
  const db = await getDb();
  if (!db) return filter("boq", (b) => b.projectId === projectId);
  return await db.select().from(boq).where(eq(boq.projectId, projectId));
}
async function getProjectExpenses(projectId) {
  const db = await getDb();
  if (!db) return filter("expenses", (e) => e.projectId === projectId);
  return await db.select().from(expenses).where(eq(expenses.projectId, projectId)).orderBy(desc(expenses.expenseDate));
}
async function getProjectInstallments(projectId) {
  const db = await getDb();
  if (!db) return filter("installments", (i) => i.projectId === projectId);
  return await db.select().from(installments).where(eq(installments.projectId, projectId)).orderBy(installments.dueDate);
}
async function createAuditLog(log) {
  const db = await getDb();
  if (!db) return;
  try {
    await db.insert(auditLogs).values(log);
  } catch (error) {
    console.error("[Database] Failed to create audit log:", error);
  }
}
async function getAuditLogs(limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(limit);
}
async function getEntityAuditLogs(entityType, entityId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(auditLogs).where(and(eq(auditLogs.entityType, entityType), eq(auditLogs.entityId, entityId))).orderBy(desc(auditLogs.createdAt));
}
async function getCompanySetting(key) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(companySettings).where(eq(companySettings.settingKey, key)).limit(1);
  return result[0] || null;
}
async function setCompanySetting(key, value, updatedBy) {
  const db = await getDb();
  if (!db) {
    const list2 = list("companySettings").filter((s) => s.settingKey !== key);
    list2.push({ id: Date.now(), settingKey: key, settingValue: value, updatedBy, updatedAt: /* @__PURE__ */ new Date() });
    write("companySettings", list2);
    return;
  }
  await db.insert(companySettings).values({
    settingKey: key,
    settingValue: value,
    updatedBy
  }).onDuplicateKeyUpdate({
    set: { settingValue: value, updatedBy }
  });
}
async function getAllCompanySettings() {
  const db = await getDb();
  if (!db) return list("companySettings");
  return await db.select().from(companySettings);
}
async function createAttachment(attachment) {
  const db = await getDb();
  if (!db) return insert("attachments", attachment);
  const result = await db.insert(attachments).values(attachment);
  return result;
}
async function getEntityAttachments(entityType, entityId) {
  const db = await getDb();
  if (!db) return filter("attachments", (a) => a.entityType === entityType && a.entityId === entityId);
  return await db.select().from(attachments).where(and(eq(attachments.entityType, entityType), eq(attachments.entityId, entityId))).orderBy(desc(attachments.createdAt));
}
async function deleteAttachment(id) {
  const db = await getDb();
  if (!db) {
    remove("attachments", id);
    return;
  }
  await db.delete(attachments).where(eq(attachments.id, id));
}
async function getUserPermissions(userId) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userPermissions).where(eq(userPermissions.userId, userId)).limit(1);
  return result[0] || null;
}
async function setUserPermissions(userId, permissions) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const json = JSON.stringify(permissions);
  await db.insert(userPermissions).values({
    userId,
    permissionsJson: json
  }).onDuplicateKeyUpdate({
    set: { permissionsJson: json }
  });
}
async function createProjectTask(task) {
  const db = await getDb();
  if (!db) return insert("projectTasks", task);
  const result = await db.insert(projectTasks).values(task);
  return result;
}
async function getProjectTasks(projectId) {
  const db = await getDb();
  if (!db) return filter("projectTasks", (t2) => t2.projectId === projectId).sort((a, b) => (b.startDate ?? 0) - (a.startDate ?? 0));
  return await db.select().from(projectTasks).where(eq(projectTasks.projectId, projectId)).orderBy(desc(projectTasks.startDate));
}
async function deleteProjectTask(id) {
  const db = await getDb();
  if (!db) return;
  await db.delete(projectTasks).where(eq(projectTasks.id, id));
}
async function globalSearch(query) {
  const db = await getDb();
  if (!db) return { clients: [], projects: [], invoices: [], forms: [] };
  const searchPattern = `%${query}%`;
  const [clientResults, projectResults, invoiceResults, formResults] = await Promise.all([
    db.select().from(clients).where(
      or(
        like(clients.name, searchPattern),
        like(clients.email, searchPattern),
        like(clients.phone, searchPattern),
        like(clients.clientNumber, searchPattern)
      )
    ).limit(10),
    db.select().from(projects).where(
      or(
        like(projects.name, searchPattern),
        like(projects.projectNumber, searchPattern),
        like(projects.description, searchPattern)
      )
    ).limit(10),
    db.select().from(invoices).where(
      like(invoices.invoiceNumber, searchPattern)
    ).limit(10),
    db.select().from(forms).where(
      like(forms.formNumber, searchPattern)
    ).limit(10)
  ]);
  return {
    clients: clientResults,
    projects: projectResults,
    invoices: invoiceResults,
    forms: formResults
  };
}
async function getDashboardStats() {
  const db = await getDb();
  if (!db) return null;
  const [clientCount, projectCount, invoiceCount, formCount] = await Promise.all([
    db.select({ count: sql`count(*)` }).from(clients),
    db.select({ count: sql`count(*)` }).from(projects),
    db.select({ count: sql`count(*)` }).from(invoices),
    db.select({ count: sql`count(*)` }).from(forms)
  ]);
  return {
    totalClients: clientCount[0]?.count || 0,
    totalProjects: projectCount[0]?.count || 0,
    totalInvoices: invoiceCount[0]?.count || 0,
    totalForms: formCount[0]?.count || 0
  };
}
async function createChangeOrder(co) {
  const db = await getDb();
  if (!db) return insert("changeOrders", co);
  const result = await db.insert(changeOrders).values(co);
  return result;
}
async function getProjectChangeOrders(projectId) {
  const db = await getDb();
  if (!db) return filter("changeOrders", (c) => c.projectId === projectId).sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
  return await db.select().from(changeOrders).where(eq(changeOrders.projectId, projectId)).orderBy(desc(changeOrders.createdAt));
}
async function getChangeOrderById(id) {
  const db = await getDb();
  if (!db) return findById("changeOrders", id);
  const result = await db.select().from(changeOrders).where(eq(changeOrders.id, id)).limit(1);
  return result[0] || null;
}
async function updateChangeOrder(id, data) {
  const db = await getDb();
  if (!db) {
    update("changeOrders", id, data);
    return;
  }
  await db.update(changeOrders).set(data).where(eq(changeOrders.id, id));
}
async function deleteChangeOrder(id) {
  const db = await getDb();
  if (!db) {
    remove("changeOrders", id);
    return;
  }
  await db.delete(changeOrders).where(eq(changeOrders.id, id));
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  if (req.secure) return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  const isSecure = isSecureRequest(req);
  const isProduction = ENV.isProduction;
  const domain = ENV.cookieDomain && ENV.cookieDomain.length > 0 ? ENV.cookieDomain : void 0;
  let sameSite = "lax";
  let secure = false;
  if (isProduction) {
    if (isSecure) {
      sameSite = "none";
      secure = true;
    } else {
      sameSite = "lax";
      secure = false;
    }
  } else {
    sameSite = "lax";
    secure = isSecure;
  }
  return {
    httpOnly: true,
    path: "/",
    secure,
    sameSite,
    domain
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    try {
      const { data } = await this.client.post(
        EXCHANGE_TOKEN_PATH,
        payload
      );
      return data;
    } catch (error) {
      if (!ENV.isProduction) {
        return {
          accessToken: "dev-access-token",
          tokenType: "Bearer",
          expiresIn: 3600,
          refreshToken: "dev-refresh-token",
          scope: "profile email",
          idToken: "dev-id-token"
        };
      }
      throw error;
    }
  }
  async getUserInfoByToken(token) {
    try {
      const { data } = await this.client.post(
        GET_USER_INFO_PATH,
        {
          accessToken: token.accessToken
        }
      );
      return data;
    } catch (error) {
      if (!ENV.isProduction) {
        return {
          openId: "dev-openid",
          projectId: ENV.appId || "local-app",
          name: "Developer",
          email: null,
          platform: "dev",
          loginMethod: "dev"
        };
      }
      throw error;
    }
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret || (!ENV.isProduction ? "manus-dev-secret" : "");
    if (!secret || secret.length < 16) {
      throw new Error("COOKIE_SECRET/JWT_SECRET is required in production and must be at least 16 chars");
    }
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    const previousSignIn = user?.lastSignedIn ?? null;
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        const email = userInfo.email ?? null;
        if (!email) {
          throw ForbiddenError("Email required");
        }
        const existing = await getUserByEmail(email);
        const emailsList = (ENV.allowedEmails || "").split(",").map((s) => s.trim()).filter(Boolean);
        const domainOk = ENV.allowedEmailDomain && email.endsWith(`@${ENV.allowedEmailDomain}`);
        const explicitOk = emailsList.includes(email);
        const canProvision = existing || ENV.allowAutoProvision || domainOk || explicitOk;
        if (!canProvision) {
          throw ForbiddenError("Access denied");
        }
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    try {
      if (!previousSignIn || signedInAt.getTime() - previousSignIn.getTime() > 10 * 60 * 1e3) {
        await createAuditLog({
          userId: user.id,
          action: "LOGIN",
          entityType: "user",
          entityId: user.id,
          details: "User signed in"
        });
      }
    } catch {
    }
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  const allowedAdminEmails = /* @__PURE__ */ new Set([]);
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      if (!userInfo.email) {
        res.status(403).json({ error: "Email required for access" });
        return;
      }
      const existing = await getUserByEmail(userInfo.email);
      if (!existing) {
        res.status(403).json({ error: "Access denied: email not registered" });
        return;
      }
      await upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
  app.get("/api/dev/login", async (req, res) => {
    const openId = getQueryParam(req, "openId") || "dev-admin";
    const name = getQueryParam(req, "name") || "Developer";
    const email = getQueryParam(req, "email") || "developer@demo.local";
    const role = getQueryParam(req, "role");
    try {
      let existing = await getUserByEmail(email);
      if (!existing) {
        await upsertUser({
          openId,
          name,
          email,
          loginMethod: "dev",
          role: role ?? "admin",
          lastSignedIn: /* @__PURE__ */ new Date()
        });
        existing = await getUserByEmail(email);
      }
      await upsertUser({
        openId,
        name,
        email: email ?? null,
        loginMethod: "dev",
        role: existing?.role ?? role ?? "admin",
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(openId, {
        name,
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[DevLogin] Failed", error);
      res.status(500).json({ error: "Dev login failed" });
    }
  });
}

// server/routers.ts
import { z as z6 } from "zod";

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/routers.ts
import { TRPCError as TRPCError7 } from "@trpc/server";

// server/storage.ts
function getStorageConfig() {
  const baseUrl = ENV.forgeApiUrl;
  const apiKey = ENV.forgeApiKey;
  if (!baseUrl || !apiKey) {
    throw new Error(
      "Storage proxy credentials missing: set BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY"
    );
  }
  return { baseUrl: baseUrl.replace(/\/+$/, ""), apiKey };
}
function buildUploadUrl(baseUrl, relKey) {
  const url = new URL("v1/storage/upload", ensureTrailingSlash(baseUrl));
  url.searchParams.set("path", normalizeKey(relKey));
  return url;
}
function ensureTrailingSlash(value) {
  return value.endsWith("/") ? value : `${value}/`;
}
function normalizeKey(relKey) {
  return relKey.replace(/^\/+/, "");
}
function toFormData(data, contentType, fileName) {
  const blob = typeof data === "string" ? new Blob([data], { type: contentType }) : new Blob([data], { type: contentType });
  const form = new FormData();
  form.append("file", blob, fileName || "file");
  return form;
}
function buildAuthHeaders(apiKey) {
  return { Authorization: `Bearer ${apiKey}` };
}
async function storagePut(relKey, data, contentType = "application/octet-stream") {
  const { baseUrl, apiKey } = getStorageConfig();
  const key = normalizeKey(relKey);
  const uploadUrl = buildUploadUrl(baseUrl, key);
  const formData = toFormData(data, contentType, key.split("/").pop() ?? key);
  const response = await fetch(uploadUrl, {
    method: "POST",
    headers: buildAuthHeaders(apiKey),
    body: formData
  });
  if (!response.ok) {
    const message = await response.text().catch(() => response.statusText);
    throw new Error(
      `Storage upload failed (${response.status} ${response.statusText}): ${message}`
    );
  }
  const url = (await response.json()).url;
  return { key, url };
}

// server/routers/hr.ts
import { z as z2 } from "zod";
import { TRPCError as TRPCError3 } from "@trpc/server";
init_schema();
import { eq as eq2, and as and2, gte, lte, desc as desc2 } from "drizzle-orm";
var adminProcedure2 = protectedProcedure.use(({ ctx, next }) => {
  if (!["admin", "hr_manager"].includes(ctx.user.role)) {
    throw new TRPCError3({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
}).use(async ({ ctx, next }) => {
  const db = await getDb();
  if (!db) return next({ ctx });
  try {
    const permsRow = await db.select().from((await Promise.resolve().then(() => (init_schema(), schema_exports))).userPermissions).where(eq2((await Promise.resolve().then(() => (init_schema(), schema_exports))).userPermissions.userId, ctx.user.id)).limit(1);
    const record = permsRow[0]?.permissionsJson ? JSON.parse(permsRow[0].permissionsJson) : {};
    if (record.hasOwnProperty("hr") && !record["hr"]) {
      throw new TRPCError3({ code: "FORBIDDEN", message: "Section access denied" });
    }
  } catch {
  }
  return next({ ctx });
});
var hrRouter = router({
  // ============= EMPLOYEES =============
  employees: router({
    list: adminProcedure2.query(async () => {
      const db = await getDb();
      if (!db) return (await Promise.resolve().then(() => (init_demoStore(), demoStore_exports))).list("employees");
      return await db.select().from(employees).orderBy(desc2(employees.createdAt));
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        const emp = demo.findById("employees", input.id);
        if (!emp) throw new TRPCError3({ code: "NOT_FOUND" });
        return emp;
      }
      const result = await db.select().from(employees).where(eq2(employees.id, input.id)).limit(1);
      if (result.length === 0) throw new TRPCError3({ code: "NOT_FOUND" });
      return result[0];
    }),
    create: adminProcedure2.input(z2.object({
      userId: z2.number(),
      employeeNumber: z2.string(),
      department: z2.string().optional(),
      position: z2.string().optional(),
      hireDate: z2.date(),
      salary: z2.number().optional(),
      bankAccount: z2.string().optional(),
      emergencyContact: z2.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.insert("employees", { ...input, status: "active" });
        return { success: true };
      }
      const values = {
        ...input,
        status: "active"
      };
      await db.insert(employees).values(values);
      return { success: true };
    }),
    update: adminProcedure2.input(z2.object({
      id: z2.number(),
      department: z2.string().optional(),
      position: z2.string().optional(),
      salary: z2.number().optional(),
      bankAccount: z2.string().optional(),
      emergencyContact: z2.string().optional(),
      status: z2.enum(["active", "on_leave", "terminated"]).optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError3({ code: "INTERNAL_SERVER_ERROR" });
      const { id, ...updateData } = input;
      await db.update(employees).set(updateData).where(eq2(employees.id, id));
      return { success: true };
    }),
    getDetails: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const employee = await db.select({
        employee: employees,
        user: users
      }).from(employees).leftJoin(users, eq2(employees.userId, users.id)).where(eq2(employees.id, input.id)).limit(1);
      if (employee.length === 0) throw new TRPCError3({ code: "NOT_FOUND" });
      const [recentAttendance, recentPayroll, activeLeaves, reviews] = await Promise.all([
        db.select().from(attendance).where(eq2(attendance.employeeId, input.id)).orderBy(desc2(attendance.date)).limit(10),
        db.select().from(payroll).where(eq2(payroll.employeeId, input.id)).orderBy(desc2(payroll.createdAt)).limit(6),
        db.select().from(leaves).where(and2(
          eq2(leaves.employeeId, input.id),
          eq2(leaves.status, "approved")
        )).orderBy(desc2(leaves.startDate)),
        db.select().from(performanceReviews).where(eq2(performanceReviews.employeeId, input.id)).orderBy(desc2(performanceReviews.reviewDate)).limit(5)
      ]);
      return {
        employee: employee[0].employee,
        user: employee[0].user,
        recentAttendance,
        recentPayroll,
        activeLeaves,
        reviews
      };
    })
  }),
  // ============= ATTENDANCE =============
  attendance: router({
    list: protectedProcedure.input(z2.object({
      employeeId: z2.number().optional(),
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        let rows = demo.list("attendance");
        if (input.employeeId) rows = rows.filter((r) => r.employeeId === input.employeeId);
        if (input.startDate) rows = rows.filter((r) => new Date(r.date) >= input.startDate);
        if (input.endDate) rows = rows.filter((r) => new Date(r.date) <= input.endDate);
        return rows.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      }
      let query = db.select().from(attendance);
      const conditions = [];
      if (input.employeeId) conditions.push(eq2(attendance.employeeId, input.employeeId));
      if (input.startDate) conditions.push(gte(attendance.date, input.startDate));
      if (input.endDate) conditions.push(lte(attendance.date, input.endDate));
      if (conditions.length > 0) {
        query = query.where(and2(...conditions));
      }
      return await query.orderBy(desc2(attendance.date));
    }),
    checkIn: protectedProcedure.input(z2.object({
      employeeId: z2.number(),
      date: z2.date()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.insert("attendance", { employeeId: input.employeeId, date: input.date, checkIn: /* @__PURE__ */ new Date(), status: "present" });
        return { success: true };
      }
      const values = {
        employeeId: input.employeeId,
        date: input.date,
        checkIn: /* @__PURE__ */ new Date(),
        status: "present"
      };
      await db.insert(attendance).values(values);
      return { success: true };
    }),
    checkOut: protectedProcedure.input(z2.object({
      id: z2.number(),
      checkOut: z2.date()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        const rec = demo.findById("attendance", input.id);
        const checkIn2 = rec?.checkIn ? new Date(rec.checkIn) : null;
        const hoursWorked2 = checkIn2 ? Math.floor((input.checkOut.getTime() - checkIn2.getTime()) / (1e3 * 60 * 60)) : 0;
        demo.update("attendance", input.id, { checkOut: input.checkOut, hoursWorked: hoursWorked2 });
        return { success: true, hoursWorked: hoursWorked2 };
      }
      const record = await db.select().from(attendance).where(eq2(attendance.id, input.id)).limit(1);
      if (record.length === 0) throw new TRPCError3({ code: "NOT_FOUND" });
      const checkIn = record[0].checkIn;
      const hoursWorked = checkIn ? Math.floor((input.checkOut.getTime() - checkIn.getTime()) / (1e3 * 60 * 60)) : 0;
      await db.update(attendance).set({ checkOut: input.checkOut, hoursWorked }).where(eq2(attendance.id, input.id));
      return { success: true, hoursWorked };
    }),
    getSummary: protectedProcedure.input(z2.object({
      employeeId: z2.number(),
      month: z2.number(),
      year: z2.number()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        return {
          totalDays: 0,
          presentDays: 0,
          absentDays: 0,
          lateDays: 0,
          totalHours: 0,
          averageHours: 0
        };
      }
      const startDate = new Date(input.year, input.month - 1, 1);
      const endDate = new Date(input.year, input.month, 0);
      const records = await db.select().from(attendance).where(and2(
        eq2(attendance.employeeId, input.employeeId),
        gte(attendance.date, startDate),
        lte(attendance.date, endDate)
      ));
      const totalDays = records.length;
      const presentDays = records.filter((r) => r.status === "present").length;
      const absentDays = records.filter((r) => r.status === "absent").length;
      const lateDays = records.filter((r) => r.status === "late").length;
      const totalHours = records.reduce((sum2, r) => sum2 + (r.hoursWorked || 0), 0);
      return {
        totalDays,
        presentDays,
        absentDays,
        lateDays,
        totalHours,
        averageHours: totalDays > 0 ? totalHours / totalDays : 0
      };
    }),
    importCsv: protectedProcedure.input(z2.object({
      csvData: z2.string()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError3({ code: "INTERNAL_SERVER_ERROR" });
      const settingsRows = await db.select().from((await Promise.resolve().then(() => (init_schema(), schema_exports))).companySettings);
      const getSetting = (k, d) => {
        const f = settingsRows.find((it) => it.settingKey === k);
        const v = f?.settingValue;
        return typeof v === "string" && v ? v : d;
      };
      const shiftStart = getSetting("hrShiftStart", "09:00");
      const graceMinutes = parseInt(getSetting("hrShiftGraceMinutes", "15"));
      const lines = input.csvData.trim().split(/\r?\n/);
      if (lines.length < 2) return { success: true, created: 0, late: 0, absent: 0 };
      const [header, ...rows] = lines;
      const cols = header.split(",").map((s) => s.trim().toLowerCase());
      const idxEmp = cols.indexOf("employeenumber");
      const idxDate = cols.indexOf("date");
      const idxIn = cols.indexOf("checkin");
      const idxOut = cols.indexOf("checkout");
      if (idxEmp < 0 || idxDate < 0) {
        throw new TRPCError3({ code: "BAD_REQUEST", message: "CSV must include employeeNumber,date[,checkIn,checkOut]" });
      }
      const employeesRows = await db.select().from((await Promise.resolve().then(() => (init_schema(), schema_exports))).employees);
      const empByNumber = /* @__PURE__ */ new Map();
      employeesRows.forEach((e) => empByNumber.set(e.employeeNumber, e));
      let created = 0, late = 0, absent = 0;
      const toTime = (dateStr, hm) => {
        const [h, m] = hm.split(":").map((x) => parseInt(x));
        const d = new Date(dateStr);
        d.setHours(h, m, 0, 0);
        return d;
      };
      for (const r of rows) {
        if (!r.trim()) continue;
        const parts = r.split(",").map((s) => s.trim());
        const empNumber = parts[idxEmp];
        const dateStr = parts[idxDate];
        const emp = empByNumber.get(empNumber);
        if (!emp) continue;
        const checkInStr = idxIn >= 0 ? parts[idxIn] : "";
        const checkOutStr = idxOut >= 0 ? parts[idxOut] : "";
        const date = new Date(dateStr);
        const plannedStart = toTime(dateStr, shiftStart);
        const graceMs = graceMinutes * 60 * 1e3;
        let status = "present";
        let checkIn = null;
        let checkOut = null;
        if (checkInStr) {
          const [ih, im] = checkInStr.split(":").map((x) => parseInt(x));
          checkIn = new Date(date);
          checkIn.setHours(ih, im, 0, 0);
        }
        if (checkOutStr) {
          const [oh, om] = checkOutStr.split(":").map((x) => parseInt(x));
          checkOut = new Date(date);
          checkOut.setHours(oh, om, 0, 0);
        }
        if (!checkIn) {
          status = "absent";
          absent++;
        } else if (checkIn.getTime() - plannedStart.getTime() > graceMs) {
          status = "late";
          late++;
        }
        let hoursWorked = 0;
        if (checkIn && checkOut) {
          hoursWorked = Math.floor((checkOut.getTime() - checkIn.getTime()) / (1e3 * 60 * 60));
        }
        await db.insert((await Promise.resolve().then(() => (init_schema(), schema_exports))).attendance).values({
          employeeId: emp.id,
          date,
          checkIn: checkIn || void 0,
          checkOut: checkOut || void 0,
          hoursWorked,
          status,
          notes: ""
        });
        created++;
      }
      return { success: true, created, late, absent };
    })
  }),
  // ============= PAYROLL =============
  payroll: router({
    list: protectedProcedure.input(z2.object({
      employeeId: z2.number().optional(),
      year: z2.number().optional(),
      month: z2.number().optional()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        let rows = demo.list("payroll");
        if (input.employeeId) rows = rows.filter((r) => r.employeeId === input.employeeId);
        if (input.year) rows = rows.filter((r) => r.year === input.year);
        if (input.month) rows = rows.filter((r) => r.month === input.month);
        return rows.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      }
      let query = db.select().from(payroll);
      const conditions = [];
      if (input.employeeId) conditions.push(eq2(payroll.employeeId, input.employeeId));
      if (input.year) conditions.push(eq2(payroll.year, input.year));
      if (input.month) conditions.push(eq2(payroll.month, input.month));
      if (conditions.length > 0) {
        query = query.where(and2(...conditions));
      }
      return await query.orderBy(desc2(payroll.createdAt));
    }),
    create: adminProcedure2.input(z2.object({
      employeeId: z2.number(),
      month: z2.number(),
      year: z2.number(),
      baseSalary: z2.number(),
      bonuses: z2.number().optional(),
      deductions: z2.number().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        const netSalary2 = input.baseSalary + (input.bonuses || 0) - (input.deductions || 0);
        demo.insert("payroll", { ...input, netSalary: netSalary2, status: "pending", createdBy: 0 });
        return { success: true, netSalary: netSalary2 };
      }
      const bonuses = input.bonuses || 0;
      const deductions = input.deductions || 0;
      const netSalary = input.baseSalary + bonuses - deductions;
      const values = {
        ...input,
        bonuses,
        deductions,
        netSalary,
        status: "pending",
        createdBy: ctx.user.id
      };
      await db.insert(payroll).values(values);
      return { success: true, netSalary };
    }),
    markPaid: adminProcedure2.input(z2.object({
      id: z2.number(),
      paymentDate: z2.date()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.update("payroll", input.id, { status: "paid", paymentDate: input.paymentDate });
        return { success: true };
      }
      await db.update(payroll).set({ status: "paid", paymentDate: input.paymentDate }).where(eq2(payroll.id, input.id));
      return { success: true };
    }),
    update: adminProcedure2.input(z2.object({
      id: z2.number(),
      status: z2.enum(["pending", "paid"]).optional(),
      paymentDate: z2.date().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) return { success: true };
      const { id, ...data } = input;
      await db.update(payroll).set(data).where(eq2(payroll.id, id));
      return { success: true };
    }),
    delete: adminProcedure2.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.remove("payroll", input.id);
        return { success: true };
      }
      await db.delete(payroll).where(eq2(payroll.id, input.id));
      return { success: true };
    }),
    generatePayslip: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError3({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.select({
        payroll,
        employee: employees,
        user: users
      }).from(payroll).leftJoin(employees, eq2(payroll.employeeId, employees.id)).leftJoin(users, eq2(employees.userId, users.id)).where(eq2(payroll.id, input.id)).limit(1);
      if (result.length === 0) throw new TRPCError3({ code: "NOT_FOUND" });
      return result[0];
    })
  }),
  // ============= LEAVES =============
  leaves: router({
    list: protectedProcedure.input(z2.object({
      employeeId: z2.number().optional(),
      status: z2.enum(["pending", "approved", "rejected"]).optional()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        let rows = demo.list("leaves");
        if (input.employeeId) rows = rows.filter((r) => r.employeeId === input.employeeId);
        if (input.status) rows = rows.filter((r) => r.status === input.status);
        return rows.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      }
      let query = db.select().from(leaves);
      const conditions = [];
      if (input.employeeId) conditions.push(eq2(leaves.employeeId, input.employeeId));
      if (input.status) conditions.push(eq2(leaves.status, input.status));
      if (conditions.length > 0) {
        query = query.where(and2(...conditions));
      }
      return await query.orderBy(desc2(leaves.createdAt));
    }),
    create: protectedProcedure.input(z2.object({
      employeeId: z2.number(),
      leaveType: z2.enum(["annual", "sick", "emergency", "unpaid"]),
      startDate: z2.date(),
      endDate: z2.date(),
      days: z2.number(),
      reason: z2.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.insert("leaves", { ...input, status: "pending" });
        return { success: true };
      }
      const values = {
        ...input,
        status: "pending"
      };
      await db.insert(leaves).values(values);
      return { success: true };
    }),
    approve: adminProcedure2.input(z2.object({
      id: z2.number(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.update("leaves", input.id, { status: "approved", approvedBy: 0, approvedAt: /* @__PURE__ */ new Date(), notes: input.notes });
        return { success: true };
      }
      await db.update(leaves).set({
        status: "approved",
        approvedBy: ctx.user.id,
        approvedAt: /* @__PURE__ */ new Date(),
        notes: input.notes
      }).where(eq2(leaves.id, input.id));
      return { success: true };
    }),
    reject: adminProcedure2.input(z2.object({
      id: z2.number(),
      notes: z2.string().optional(),
      reason: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.update("leaves", input.id, { status: "rejected", approvedBy: 0, approvedAt: /* @__PURE__ */ new Date(), notes: input.notes ?? input.reason });
        return { success: true };
      }
      await db.update(leaves).set({
        status: "rejected",
        approvedBy: ctx.user.id,
        approvedAt: /* @__PURE__ */ new Date(),
        notes: input.notes ?? input.reason
      }).where(eq2(leaves.id, input.id));
      return { success: true };
    })
  }),
  // ============= PERFORMANCE REVIEWS =============
  reviews: router({
    list: protectedProcedure.input(z2.object({
      employeeId: z2.number().optional()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        let rows = demo.list("performanceReviews");
        if (input.employeeId) rows = rows.filter((r) => r.employeeId === input.employeeId);
        return rows.sort((a, b) => new Date(b.reviewDate || b.createdAt || 0).getTime() - new Date(a.reviewDate || a.createdAt || 0).getTime());
      }
      let query = db.select().from(performanceReviews);
      if (input.employeeId) {
        query = query.where(eq2(performanceReviews.employeeId, input.employeeId));
      }
      return await query.orderBy(desc2(performanceReviews.reviewDate));
    }),
    create: adminProcedure2.input(z2.object({
      employeeId: z2.number(),
      reviewDate: z2.date(),
      period: z2.string().optional(),
      rating: z2.number().optional(),
      strengths: z2.string().optional(),
      weaknesses: z2.string().optional(),
      goals: z2.string().optional(),
      comments: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.insert("performanceReviews", { ...input, reviewerId: 0 });
        return { success: true };
      }
      const values = {
        ...input,
        reviewerId: ctx.user.id
      };
      await db.insert(performanceReviews).values(values);
      return { success: true };
    }),
    delete: adminProcedure2.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const demo = await Promise.resolve().then(() => (init_demoStore(), demoStore_exports));
        demo.remove("performanceReviews", input.id);
        return { success: true };
      }
      await db.delete(performanceReviews).where(eq2(performanceReviews.id, input.id));
      return { success: true };
    })
  })
});

// server/routers/accounting.ts
import { z as z3 } from "zod";
import { TRPCError as TRPCError4 } from "@trpc/server";
init_schema();
init_demoStore();
import { eq as eq3, and as and3, desc as desc3, sum, sql as sql2 } from "drizzle-orm";
var accountingProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "accountant") {
    throw new TRPCError4({ code: "FORBIDDEN", message: "Accounting access required" });
  }
  return next({ ctx });
}).use(async ({ ctx, next }) => {
  const db = await getDb();
  if (!db) return next({ ctx });
  try {
    const permsRow = await db.select().from((await Promise.resolve().then(() => (init_schema(), schema_exports))).userPermissions).where(eq3((await Promise.resolve().then(() => (init_schema(), schema_exports))).userPermissions.userId, ctx.user.id)).limit(1);
    const record = permsRow[0]?.permissionsJson ? JSON.parse(permsRow[0].permissionsJson) : {};
    if (record.hasOwnProperty("accounting") && !record["accounting"]) {
      throw new TRPCError4({ code: "FORBIDDEN", message: "Section access denied" });
    }
  } catch {
  }
  return next({ ctx });
});
var accountingRouter = router({
  // ============= EXPENSES =============
  expenses: router({
    list: accountingProcedure.input(z3.object({
      projectId: z3.number().optional(),
      startDate: z3.number().optional(),
      endDate: z3.number().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("expenses").sort((a, b) => new Date(b.expenseDate || b.createdAt || 0).getTime() - new Date(a.expenseDate || a.createdAt || 0).getTime());
        if (input?.projectId) rows = rows.filter((r) => r.projectId === input.projectId);
        return rows;
      }
      let query = db.select().from(expenses).orderBy(desc3(expenses.expenseDate));
      if (input?.projectId) {
        query = query.where(eq3(expenses.projectId, input.projectId));
      }
      return await query;
    }),
    create: accountingProcedure.input(z3.object({
      projectId: z3.number(),
      category: z3.string(),
      description: z3.string(),
      amount: z3.number(),
      expenseDate: z3.string()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        insert("expenses", {
          projectId: input.projectId,
          category: input.category,
          description: input.description,
          amount: input.amount,
          expenseDate: new Date(input.expenseDate)
        });
        return { success: true };
      }
      await db.insert(expenses).values({
        projectId: input.projectId,
        category: input.category,
        description: input.description,
        amount: input.amount,
        expenseDate: new Date(input.expenseDate),
        createdBy: 1
        // TODO: use ctx.user.id
      });
      return { success: true };
    }),
    update: accountingProcedure.input(z3.object({
      id: z3.number(),
      category: z3.string().optional(),
      description: z3.string().optional(),
      amount: z3.number().optional(),
      expenseDate: z3.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const { id: id2, expenseDate: expenseDate2, ...data2 } = input;
        const updateData2 = { ...data2 };
        if (expenseDate2) updateData2.expenseDate = new Date(expenseDate2);
        update("expenses", id2, updateData2);
        return { success: true };
      }
      const { id, expenseDate, ...data } = input;
      const updateData = { ...data };
      if (expenseDate) {
        updateData.expenseDate = new Date(expenseDate);
      }
      await db.update(expenses).set(updateData).where(eq3(expenses.id, id));
      return { success: true };
    }),
    delete: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        remove("expenses", input.id);
        return { success: true };
      }
      await db.delete(expenses).where(eq3(expenses.id, input.id));
      return { success: true };
    }),
    cancel: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        update("expenses", input.id, { status: "cancelled" });
        return { success: true };
      }
      await db.update(expenses).set({ status: "cancelled" }).where(eq3(expenses.id, input.id));
      return { success: true };
    }),
    summary: accountingProcedure.input(z3.object({
      projectId: z3.number().optional(),
      startDate: z3.number().optional(),
      endDate: z3.number().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("expenses");
        if (input?.projectId) rows = rows.filter((r) => r.projectId === input.projectId);
        const totalAmount = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const count = rows.length;
        return { totalAmount, count };
      }
      let conditions = [];
      if (input?.projectId) conditions.push(eq3(expenses.projectId, input.projectId));
      const result = await db.select({
        total: sum(expenses.amount),
        count: sql2`count(*)`
      }).from(expenses).where(conditions.length > 0 ? and3(...conditions) : void 0);
      return {
        totalAmount: Number(result[0]?.total || 0),
        count: Number(result[0]?.count || 0)
      };
    })
  }),
  // ============= BOQ (Bill of Quantities) =============
  boq: router({
    list: accountingProcedure.input(z3.object({
      projectId: z3.number().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("boq").sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
        if (input?.projectId) rows = rows.filter((r) => r.projectId === input.projectId);
        return rows;
      }
      let query = db.select().from(boq).orderBy(desc3(boq.createdAt));
      if (input?.projectId) {
        query = query.where(eq3(boq.projectId, input.projectId));
      }
      return await query;
    }),
    create: accountingProcedure.input(z3.object({
      projectId: z3.number(),
      itemNumber: z3.string(),
      description: z3.string(),
      unit: z3.string(),
      quantity: z3.number(),
      unitPrice: z3.number(),
      category: z3.string().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const totalPrice2 = input.quantity * input.unitPrice;
        insert("boq", {
          projectId: input.projectId,
          itemName: input.itemNumber,
          description: input.description,
          unit: input.unit,
          quantity: input.quantity,
          unitPrice: input.unitPrice,
          total: totalPrice2,
          category: input.category
        });
        return { success: true };
      }
      const totalPrice = input.quantity * input.unitPrice;
      await db.insert(boq).values({
        projectId: input.projectId,
        itemName: input.itemNumber,
        description: input.description,
        unit: input.unit,
        quantity: input.quantity,
        unitPrice: input.unitPrice,
        total: totalPrice,
        category: input.category
      });
      return { success: true };
    }),
    update: accountingProcedure.input(z3.object({
      id: z3.number(),
      itemNumber: z3.string().optional(),
      description: z3.string().optional(),
      unit: z3.string().optional(),
      quantity: z3.number().optional(),
      unitPrice: z3.number().optional(),
      category: z3.string().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const { id: id2, ...data2 } = input;
        update("boq", id2, data2);
        return { success: true };
      }
      const { id, ...data } = input;
      let updateData = { ...data };
      if (data.quantity !== void 0 || data.unitPrice !== void 0) {
        const [current] = await db.select().from(boq).where(eq3(boq.id, id));
        const newQuantity = data.quantity ?? current.quantity;
        const newUnitPrice = data.unitPrice ?? current.unitPrice;
        updateData.total = newQuantity * newUnitPrice;
      }
      await db.update(boq).set(updateData).where(eq3(boq.id, id));
      return { success: true };
    }),
    delete: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        remove("boq", input.id);
        return { success: true };
      }
      await db.delete(boq).where(eq3(boq.id, input.id));
      return { success: true };
    }),
    summary: accountingProcedure.input(z3.object({
      projectId: z3.number()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const rows = list("boq").filter((r) => r.projectId === input.projectId);
        const totalAmount = rows.reduce((s, r) => s + Number(r.total || 0), 0);
        const itemCount = rows.length;
        return { totalAmount, itemCount };
      }
      const result = await db.select({
        total: sum(boq.total),
        count: sql2`count(*)`
      }).from(boq).where(eq3(boq.projectId, input.projectId));
      return {
        totalAmount: Number(result[0]?.total || 0),
        itemCount: Number(result[0]?.count || 0)
      };
    })
  }),
  // ============= INSTALLMENTS =============
  installments: router({
    list: accountingProcedure.input(z3.object({
      projectId: z3.number().optional(),
      status: z3.enum(["pending", "paid", "overdue"]).optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("installments");
        if (input?.projectId) rows = rows.filter((r) => r.projectId === input.projectId);
        if (input?.status) rows = rows.filter((r) => r.status === input.status);
        return rows.sort((a, b) => new Date(b.dueDate || b.createdAt || 0).getTime() - new Date(a.dueDate || a.createdAt || 0).getTime());
      }
      let conditions = [];
      if (input?.projectId) conditions.push(eq3(installments.projectId, input.projectId));
      if (input?.status) conditions.push(eq3(installments.status, input.status));
      return await db.select().from(installments).where(conditions.length > 0 ? and3(...conditions) : void 0).orderBy(desc3(installments.dueDate));
    }),
    create: accountingProcedure.input(z3.object({
      projectId: z3.number(),
      installmentNumber: z3.number(),
      amount: z3.number(),
      dueDate: z3.number(),
      description: z3.string().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        insert("installments", {
          projectId: input.projectId,
          installmentNumber: input.installmentNumber,
          amount: input.amount,
          dueDate: new Date(input.dueDate),
          status: "pending",
          notes: input.notes
        });
        return { success: true };
      }
      await db.insert(installments).values({
        projectId: input.projectId,
        installmentNumber: input.installmentNumber,
        amount: input.amount,
        dueDate: new Date(input.dueDate),
        status: "pending",
        notes: input.notes
      });
      return { success: true };
    }),
    update: accountingProcedure.input(z3.object({
      id: z3.number(),
      amount: z3.number().optional(),
      dueDate: z3.number().optional(),
      status: z3.enum(["pending", "paid", "overdue"]).optional(),
      paidDate: z3.number().optional(),
      description: z3.string().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const { id: id2, dueDate: dueDate2, paidDate: paidDate2, ...data2 } = input;
        const updateData2 = { ...data2 };
        if (dueDate2) updateData2.dueDate = new Date(dueDate2);
        if (paidDate2) updateData2.paidDate = new Date(paidDate2);
        update("installments", id2, updateData2);
        return { success: true };
      }
      const { id, dueDate, paidDate, ...data } = input;
      const updateData = { ...data };
      if (dueDate) updateData.dueDate = new Date(dueDate);
      if (paidDate) updateData.paidDate = new Date(paidDate);
      await db.update(installments).set(updateData).where(eq3(installments.id, id));
      return { success: true };
    }),
    markAsPaid: accountingProcedure.input(z3.object({
      id: z3.number(),
      paidDate: z3.number().optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        update("installments", input.id, { status: "paid", paidDate: input.paidDate ? new Date(input.paidDate) : /* @__PURE__ */ new Date() });
        return { success: true };
      }
      await db.update(installments).set({
        status: "paid",
        paidDate: input.paidDate ? new Date(input.paidDate) : /* @__PURE__ */ new Date()
      }).where(eq3(installments.id, input.id));
      return { success: true };
    }),
    delete: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        remove("installments", input.id);
        return { success: true };
      }
      await db.delete(installments).where(eq3(installments.id, input.id));
      return { success: true };
    }),
    cancel: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        update("installments", input.id, { status: "cancelled" });
        return { success: true };
      }
      await db.update(installments).set({ status: "cancelled" }).where(eq3(installments.id, input.id));
      return { success: true };
    }),
    summary: accountingProcedure.input(z3.object({
      projectId: z3.number().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("installments");
        if (input?.projectId) rows = rows.filter((r) => r.projectId === input.projectId);
        const totalAmount = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const paidAmount = rows.filter((r) => r.status === "paid").reduce((s, r) => s + Number(r.amount || 0), 0);
        const pendingAmount = rows.filter((r) => r.status === "pending").reduce((s, r) => s + Number(r.amount || 0), 0);
        const count = rows.length;
        return { totalAmount, paidAmount, pendingAmount, count };
      }
      const conditions = input?.projectId ? [eq3(installments.projectId, input.projectId)] : [];
      const allResult = await db.select({
        total: sum(installments.amount),
        count: sql2`count(*)`
      }).from(installments).where(conditions.length > 0 ? and3(...conditions) : void 0);
      const paidResult = await db.select({
        total: sum(installments.amount)
      }).from(installments).where(and3(
        eq3(installments.status, "paid"),
        ...conditions.length > 0 ? conditions : []
      ));
      const pendingResult = await db.select({
        total: sum(installments.amount)
      }).from(installments).where(and3(
        eq3(installments.status, "pending"),
        ...conditions.length > 0 ? conditions : []
      ));
      return {
        totalAmount: Number(allResult[0]?.total || 0),
        paidAmount: Number(paidResult[0]?.total || 0),
        pendingAmount: Number(pendingResult[0]?.total || 0),
        count: Number(allResult[0]?.count || 0)
      };
    })
  }),
  // ============= SALES =============
  sales: router({
    list: accountingProcedure.query(async () => {
      const db = await getDb();
      if (!db) return list("sales").sort((a, b) => new Date(b.saleDate || b.createdAt || 0).getTime() - new Date(a.saleDate || a.createdAt || 0).getTime());
      return await db.select().from(sales).orderBy(desc3(sales.saleDate));
    }),
    create: accountingProcedure.input(z3.object({
      clientId: z3.number(),
      projectId: z3.number().optional(),
      description: z3.string(),
      amount: z3.number(),
      paymentMethod: z3.enum(["cash", "bank_transfer", "check", "credit"]),
      saleDate: z3.string(),
      invoiceId: z3.number().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        const saleNumber2 = `SAL-${Date.now()}`;
        insert("sales", {
          saleNumber: saleNumber2,
          ...input,
          saleDate: new Date(input.saleDate),
          createdBy: ctx.user.id,
          status: "completed"
        });
        return { success: true };
      }
      const saleNumber = `SAL-${Date.now()}`;
      await db.insert(sales).values({
        saleNumber,
        ...input,
        saleDate: new Date(input.saleDate),
        createdBy: ctx.user.id,
        status: "completed"
      });
      return { success: true };
    }),
    cancel: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        update("sales", input.id, { status: "cancelled" });
        return { success: true };
      }
      await db.update(sales).set({ status: "cancelled" }).where(eq3(sales.id, input.id));
      return { success: true };
    }),
    update: accountingProcedure.input(z3.object({
      id: z3.number(),
      projectId: z3.number().optional(),
      description: z3.string().optional(),
      amount: z3.number().optional(),
      paymentMethod: z3.enum(["cash", "bank_transfer", "check", "credit"]).optional(),
      saleDate: z3.string().optional(),
      invoiceId: z3.number().optional(),
      notes: z3.string().optional(),
      status: z3.enum(["pending", "completed", "cancelled"]).optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const { id: id2, saleDate: saleDate2, ...data2 } = input;
        const updateData2 = { ...data2 };
        if (saleDate2) updateData2.saleDate = new Date(saleDate2);
        update("sales", id2, updateData2);
        return { success: true };
      }
      const { id, saleDate, ...data } = input;
      const updateData = { ...data };
      if (saleDate) updateData.saleDate = new Date(saleDate);
      await db.update(sales).set(updateData).where(eq3(sales.id, id));
      return { success: true };
    }),
    delete: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        remove("sales", input.id);
        return { success: true };
      }
      await db.delete(sales).where(eq3(sales.id, input.id));
      return { success: true };
    }),
    getTotalSales: accountingProcedure.input(z3.object({
      startDate: z3.string().optional(),
      endDate: z3.string().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("sales").filter((r) => (r.status || "completed") === "completed");
        if (input?.startDate) rows = rows.filter((r) => new Date(r.saleDate || r.createdAt || 0) >= new Date(input.startDate));
        if (input?.endDate) rows = rows.filter((r) => new Date(r.saleDate || r.createdAt || 0) <= new Date(input.endDate));
        const total = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const count = rows.length;
        return { total, count };
      }
      let conditions = [eq3(sales.status, "completed")];
      if (input?.startDate) {
        conditions.push(sql2`${sales.saleDate} >= ${new Date(input.startDate)}`);
      }
      if (input?.endDate) {
        conditions.push(sql2`${sales.saleDate} <= ${new Date(input.endDate)}`);
      }
      const result = await db.select({
        total: sum(sales.amount),
        count: sql2`COUNT(*)`
      }).from(sales).where(and3(...conditions));
      return { total: Number(result[0]?.total || 0), count: Number(result[0]?.count || 0) };
    })
  }),
  // ============= PURCHASES =============
  purchases: router({
    list: accountingProcedure.query(async () => {
      const db = await getDb();
      if (!db) return list("purchases").sort((a, b) => new Date(b.purchaseDate || b.createdAt || 0).getTime() - new Date(a.purchaseDate || a.createdAt || 0).getTime());
      return await db.select().from(purchases).orderBy(desc3(purchases.purchaseDate));
    }),
    create: accountingProcedure.input(z3.object({
      supplierId: z3.number().optional(),
      supplierName: z3.string(),
      projectId: z3.number().optional(),
      description: z3.string(),
      amount: z3.number(),
      paymentMethod: z3.enum(["cash", "bank_transfer", "check", "credit"]),
      purchaseDate: z3.string(),
      category: z3.string().optional(),
      notes: z3.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        const purchaseNumber2 = `PUR-${Date.now()}`;
        insert("purchases", {
          purchaseNumber: purchaseNumber2,
          ...input,
          purchaseDate: new Date(input.purchaseDate),
          createdBy: ctx.user.id,
          status: "completed"
        });
        return { success: true };
      }
      const purchaseNumber = `PUR-${Date.now()}`;
      await db.insert(purchases).values({
        purchaseNumber,
        ...input,
        purchaseDate: new Date(input.purchaseDate),
        createdBy: ctx.user.id,
        status: "completed"
      });
      return { success: true };
    }),
    cancel: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        update("purchases", input.id, { status: "cancelled" });
        return { success: true };
      }
      await db.update(purchases).set({ status: "cancelled" }).where(eq3(purchases.id, input.id));
      return { success: true };
    }),
    update: accountingProcedure.input(z3.object({
      id: z3.number(),
      supplierId: z3.number().optional(),
      supplierName: z3.string().optional(),
      projectId: z3.number().optional(),
      description: z3.string().optional(),
      amount: z3.number().optional(),
      paymentMethod: z3.enum(["cash", "bank_transfer", "check", "credit"]).optional(),
      purchaseDate: z3.string().optional(),
      category: z3.string().optional(),
      notes: z3.string().optional(),
      status: z3.enum(["pending", "completed", "cancelled"]).optional()
    })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const { id: id2, purchaseDate: purchaseDate2, ...data2 } = input;
        const updateData2 = { ...data2 };
        if (purchaseDate2) updateData2.purchaseDate = new Date(purchaseDate2);
        update("purchases", id2, updateData2);
        return { success: true };
      }
      const { id, purchaseDate, ...data } = input;
      const updateData = { ...data };
      if (purchaseDate) updateData.purchaseDate = new Date(purchaseDate);
      await db.update(purchases).set(updateData).where(eq3(purchases.id, id));
      return { success: true };
    }),
    delete: accountingProcedure.input(z3.object({ id: z3.number() })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        remove("purchases", input.id);
        return { success: true };
      }
      await db.delete(purchases).where(eq3(purchases.id, input.id));
      return { success: true };
    }),
    getTotalPurchases: accountingProcedure.input(z3.object({
      startDate: z3.string().optional(),
      endDate: z3.string().optional()
    }).optional()).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        let rows = list("purchases").filter((r) => (r.status || "completed") === "completed");
        if (input?.startDate) rows = rows.filter((r) => new Date(r.purchaseDate || r.createdAt || 0) >= new Date(input.startDate));
        if (input?.endDate) rows = rows.filter((r) => new Date(r.purchaseDate || r.createdAt || 0) <= new Date(input.endDate));
        const total = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const count = rows.length;
        return { total, count };
      }
      let conditions = [eq3(purchases.status, "completed")];
      if (input?.startDate) {
        conditions.push(sql2`${purchases.purchaseDate} >= ${new Date(input.startDate)}`);
      }
      if (input?.endDate) {
        conditions.push(sql2`${purchases.purchaseDate} <= ${new Date(input.endDate)}`);
      }
      const result = await db.select({
        total: sum(purchases.amount),
        count: sql2`COUNT(*)`
      }).from(purchases).where(and3(...conditions));
      return { total: Number(result[0]?.total || 0), count: Number(result[0]?.count || 0) };
    })
  }),
  // ============= FINANCIAL REPORTS =============
  reports: router({
    projectFinancials: accountingProcedure.input(z3.object({
      projectId: z3.number()
    })).query(async ({ input }) => {
      const db = await getDb();
      if (!db) {
        const expensesRows = list("expenses").filter((r) => r.projectId === input.projectId);
        const boqRows = list("boq").filter((r) => r.projectId === input.projectId);
        const instRows = list("installments").filter((r) => r.projectId === input.projectId);
        const totalExpenses2 = expensesRows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const totalBOQ2 = boqRows.reduce((s, r) => s + Number(r.total || 0), 0);
        const totalRevenue2 = instRows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const paidRevenue2 = instRows.filter((r) => r.status === "paid").reduce((s, r) => s + Number(r.amount || 0), 0);
        return {
          projectId: input.projectId,
          totalExpenses: totalExpenses2,
          totalBOQ: totalBOQ2,
          totalRevenue: totalRevenue2,
          paidRevenue: paidRevenue2,
          pendingRevenue: totalRevenue2 - paidRevenue2,
          netProfit: paidRevenue2 - totalExpenses2,
          profitMargin: paidRevenue2 > 0 ? (paidRevenue2 - totalExpenses2) / paidRevenue2 * 100 : 0
        };
      }
      const expensesResult = await db.select({
        total: sum(expenses.amount)
      }).from(expenses).where(eq3(expenses.projectId, input.projectId));
      const boqResult = await db.select({
        total: sum(boq.total)
      }).from(boq).where(eq3(boq.projectId, input.projectId));
      const installmentsResult = await db.select({
        total: sum(installments.amount),
        paid: sql2`sum(case when ${installments.status} = 'paid' then ${installments.amount} else 0 end)`
      }).from(installments).where(eq3(installments.projectId, input.projectId));
      const totalExpenses = Number(expensesResult[0]?.total || 0);
      const totalBOQ = Number(boqResult[0]?.total || 0);
      const totalRevenue = Number(installmentsResult[0]?.total || 0);
      const paidRevenue = Number(installmentsResult[0]?.paid || 0);
      return {
        projectId: input.projectId,
        totalExpenses,
        totalBOQ,
        totalRevenue,
        paidRevenue,
        pendingRevenue: totalRevenue - paidRevenue,
        netProfit: paidRevenue - totalExpenses,
        profitMargin: paidRevenue > 0 ? (paidRevenue - totalExpenses) / paidRevenue * 100 : 0
      };
    }),
    overallFinancials: accountingProcedure.query(async () => {
      const db = await getDb();
      if (!db) {
        const expensesRows = list("expenses");
        const instRows = list("installments");
        const salesRows = list("sales").filter((r) => (r.status || "completed") === "completed");
        const purchasesRows = list("purchases").filter((r) => (r.status || "completed") === "completed");
        const totalExpenses2 = expensesRows.reduce((s, r) => s + Number(r.amount || 0), 0) + purchasesRows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const installmentsRevenue = instRows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const salesRevenue = salesRows.reduce((s, r) => s + Number(r.amount || 0), 0);
        const totalRevenue2 = installmentsRevenue + salesRevenue;
        const paidRevenue2 = instRows.filter((r) => r.status === "paid").reduce((s, r) => s + Number(r.amount || 0), 0) + salesRevenue;
        return {
          totalExpenses: totalExpenses2,
          totalRevenue: totalRevenue2,
          paidRevenue: paidRevenue2,
          pendingRevenue: totalRevenue2 - paidRevenue2,
          netProfit: paidRevenue2 - totalExpenses2,
          profitMargin: paidRevenue2 > 0 ? (paidRevenue2 - totalExpenses2) / paidRevenue2 * 100 : 0
        };
      }
      const expensesResult = await db.select({ total: sum(expenses.amount) }).from(expenses);
      const purchasesRes = await db.select({ total: sum(purchases.amount) }).from(purchases).where(eq3(purchases.status, "completed"));
      const instRes = await db.select({
        total: sum(installments.amount),
        paid: sql2`sum(case when ${installments.status} = 'paid' then ${installments.amount} else 0 end)`
      }).from(installments);
      const salesTable = (await Promise.resolve().then(() => (init_schema(), schema_exports))).sales;
      const salesRes = await db.select({ total: sum(salesTable.amount) }).from(salesTable).where(eq3(salesTable.status, "completed"));
      const totalExpenses = Number(expensesResult[0]?.total || 0) + Number(purchasesRes[0]?.total || 0);
      const totalRevenue = Number(instRes[0]?.total || 0) + Number(salesRes[0]?.total || 0);
      const paidRevenue = Number(instRes[0]?.paid || 0) + Number(salesRes[0]?.total || 0);
      return {
        totalExpenses,
        totalRevenue,
        paidRevenue,
        pendingRevenue: totalRevenue - paidRevenue,
        netProfit: paidRevenue - totalExpenses,
        profitMargin: paidRevenue > 0 ? (paidRevenue - totalExpenses) / paidRevenue * 100 : 0
      };
    })
  })
});

// server/routers/reports.ts
import { z as z4 } from "zod";
import { TRPCError as TRPCError5 } from "@trpc/server";
init_schema();
init_demoStore();
import { and as and4, gte as gte3, lte as lte3, sql as sql3 } from "drizzle-orm";
var reportsRouter = router({
  summary: protectedProcedure.input(z4.object({
    from: z4.date().optional(),
    to: z4.date().optional(),
    clientId: z4.number().optional(),
    projectId: z4.number().optional(),
    invoiceStatus: z4.enum(["draft", "sent", "paid", "cancelled"]).optional(),
    purchaseStatus: z4.enum(["pending", "completed", "cancelled"]).optional(),
    installmentStatus: z4.enum(["pending", "paid", "overdue", "cancelled"]).optional(),
    expenseStatus: z4.enum(["active", "cancelled"]).optional()
  })).query(async ({ input, ctx }) => {
    if (!["admin", "accountant"].includes(ctx.user.role)) {
      throw new TRPCError5({ code: "FORBIDDEN" });
    }
    const conn = await getDb();
    if (!conn) {
      const from2 = input.from ?? /* @__PURE__ */ new Date(0);
      const to2 = input.to ?? /* @__PURE__ */ new Date();
      const within = (d) => {
        const dt = d ? new Date(d) : null;
        if (!dt) return false;
        return dt >= from2 && dt <= to2;
      };
      const invRows = list("invoices").filter((r) => within(r.issueDate));
      const purRows = list("purchases").filter((r) => within(r.purchaseDate));
      const expRows = list("expenses").filter((r) => within(r.expenseDate));
      const instRows = list("installments").filter((r) => within(r.createdAt));
      return {
        invoicesTotal: invRows.reduce((s, r) => s + Number(r.total || 0), 0),
        purchasesTotal: purRows.reduce((s, r) => s + Number(r.amount || 0), 0),
        expensesTotal: expRows.reduce((s, r) => s + Number(r.amount || 0), 0),
        installmentsTotal: instRows.reduce((s, r) => s + Number(r.amount || 0), 0),
        net: invRows.reduce((s, r) => s + Number(r.total || 0), 0) + instRows.reduce((s, r) => s + Number(r.amount || 0), 0) - purRows.reduce((s, r) => s + Number(r.amount || 0), 0) - expRows.reduce((s, r) => s + Number(r.amount || 0), 0)
      };
    }
    const from = input.from ?? /* @__PURE__ */ new Date(0);
    const to = input.to ?? /* @__PURE__ */ new Date();
    const invWhere = [gte3(invoices.issueDate, from), lte3(invoices.issueDate, to)];
    if (input.clientId) invWhere.push(sql3`${invoices.clientId} = ${input.clientId}`);
    if (input.projectId) invWhere.push(sql3`${invoices.projectId} = ${input.projectId}`);
    if (input.invoiceStatus) invWhere.push(sql3`${invoices.status} = ${input.invoiceStatus}`);
    const invSum = await conn.select({ total: sql3`SUM(${invoices.total})` }).from(invoices).where(and4(...invWhere));
    const purWhere = [gte3(purchases.purchaseDate, from), lte3(purchases.purchaseDate, to)];
    if (input.projectId) purWhere.push(sql3`${purchases.projectId} = ${input.projectId}`);
    if (input.purchaseStatus) purWhere.push(sql3`${purchases.status} = ${input.purchaseStatus}`);
    const purSum = await conn.select({ total: sql3`SUM(${purchases.amount})` }).from(purchases).where(and4(...purWhere));
    const expWhere = [gte3(expenses.expenseDate, from), lte3(expenses.expenseDate, to)];
    if (input.projectId) expWhere.push(sql3`${expenses.projectId} = ${input.projectId}`);
    if (input.expenseStatus) expWhere.push(sql3`${expenses.status} = ${input.expenseStatus}`);
    const expSum = await conn.select({ total: sql3`SUM(${expenses.amount})` }).from(expenses).where(and4(...expWhere));
    const instWhere = [gte3(installments.createdAt, from), lte3(installments.createdAt, to)];
    if (input.projectId) instWhere.push(sql3`${installments.projectId} = ${input.projectId}`);
    if (input.installmentStatus) instWhere.push(sql3`${installments.status} = ${input.installmentStatus}`);
    const instSum = await conn.select({ total: sql3`SUM(${installments.amount})` }).from(installments).where(and4(...instWhere));
    const invoicesTotal = invSum[0]?.total ?? 0;
    const purchasesTotal = purSum[0]?.total ?? 0;
    const expensesTotal = expSum[0]?.total ?? 0;
    const installmentsTotal = instSum[0]?.total ?? 0;
    const net = invoicesTotal + installmentsTotal - purchasesTotal - expensesTotal;
    return { invoicesTotal, purchasesTotal, expensesTotal, installmentsTotal, net };
  }),
  timeseries: protectedProcedure.input(z4.object({
    from: z4.date(),
    to: z4.date(),
    granularity: z4.enum(["day", "month"]).default("day"),
    clientId: z4.number().optional(),
    projectId: z4.number().optional(),
    invoiceStatus: z4.enum(["draft", "sent", "paid", "cancelled"]).optional(),
    purchaseStatus: z4.enum(["pending", "completed", "cancelled"]).optional(),
    installmentStatus: z4.enum(["pending", "paid", "overdue", "cancelled"]).optional(),
    expenseStatus: z4.enum(["active", "cancelled"]).optional()
  })).query(async ({ input, ctx }) => {
    if (!["admin", "accountant"].includes(ctx.user.role)) {
      throw new TRPCError5({ code: "FORBIDDEN" });
    }
    const conn = await getDb();
    const from = input.from;
    const to = input.to;
    const range = [];
    const cursor = new Date(from);
    const makeKey = (d) => input.granularity === "month" ? `${d.getFullYear()}-${d.getMonth() + 1}` : d.toISOString().substring(0, 10);
    while (cursor <= to) {
      range.push({ key: makeKey(cursor), date: new Date(cursor) });
      if (input.granularity === "month") {
        cursor.setMonth(cursor.getMonth() + 1);
        cursor.setDate(1);
      } else {
        cursor.setDate(cursor.getDate() + 1);
      }
    }
    if (!conn) {
      const invRows2 = list("invoices");
      const expRows2 = list("expenses");
      const instRows2 = list("installments");
      const makeKey2 = (d) => input.granularity === "month" ? `${d.getFullYear()}-${d.getMonth() + 1}` : d.toISOString().substring(0, 10);
      const acc2 = {};
      range.forEach((r) => {
        acc2[r.key] = { invoices: 0, expenses: 0, installments: 0 };
      });
      invRows2.forEach((r) => {
        const d = new Date(r.issueDate || r.createdAt || Date.now());
        const k = makeKey2(d);
        if (acc2[k]) acc2[k].invoices += Number(r.total || 0);
      });
      expRows2.forEach((r) => {
        const d = new Date(r.expenseDate || r.createdAt || Date.now());
        const k = makeKey2(d);
        if (acc2[k]) acc2[k].expenses += Number(r.amount || 0);
      });
      instRows2.forEach((r) => {
        const d = new Date(r.createdAt || Date.now());
        const k = makeKey2(d);
        if (acc2[k]) acc2[k].installments += Number(r.amount || 0);
      });
      return range.map((r) => {
        const v = acc2[r.key] || { invoices: 0, expenses: 0, installments: 0 };
        const net = v.invoices + v.installments - v.expenses;
        return { dateKey: r.key, invoices: v.invoices, expenses: v.expenses, installments: v.installments, net };
      });
    }
    const invWhere = [gte3(invoices.issueDate, from), lte3(invoices.issueDate, to)];
    if (input.clientId) invWhere.push(sql3`${invoices.clientId} = ${input.clientId}`);
    if (input.projectId) invWhere.push(sql3`${invoices.projectId} = ${input.projectId}`);
    if (input.invoiceStatus) invWhere.push(sql3`${invoices.status} = ${input.invoiceStatus}`);
    const invRows = await conn.select().from(invoices).where(and4(...invWhere));
    const expWhere = [gte3(expenses.expenseDate, from), lte3(expenses.expenseDate, to)];
    if (input.projectId) expWhere.push(sql3`${expenses.projectId} = ${input.projectId}`);
    if (input.expenseStatus) expWhere.push(sql3`${expenses.status} = ${input.expenseStatus}`);
    const expRows = await conn.select().from(expenses).where(and4(...expWhere));
    const instWhere = [gte3(installments.createdAt, from), lte3(installments.createdAt, to)];
    if (input.projectId) instWhere.push(sql3`${installments.projectId} = ${input.projectId}`);
    if (input.installmentStatus) instWhere.push(sql3`${installments.status} = ${input.installmentStatus}`);
    const instRows = await conn.select().from(installments).where(and4(...instWhere));
    const acc = {};
    range.forEach((r) => {
      acc[r.key] = { invoices: 0, expenses: 0, installments: 0 };
    });
    invRows.forEach((r) => {
      const d = new Date(r.issueDate);
      const key = makeKey(d);
      if (acc[key]) acc[key].invoices += Number(r.total || 0);
    });
    expRows.forEach((r) => {
      const d = new Date(r.expenseDate);
      const key = makeKey(d);
      if (acc[key]) acc[key].expenses += Number(r.amount || 0);
    });
    instRows.forEach((r) => {
      const d = new Date(r.createdAt);
      const key = makeKey(d);
      if (acc[key]) acc[key].installments += Number(r.amount || 0);
    });
    return range.map((r) => {
      const v = acc[r.key] || { invoices: 0, expenses: 0, installments: 0 };
      const net = v.invoices + v.installments - v.expenses;
      return { dateKey: r.key, invoices: v.invoices, expenses: v.expenses, installments: v.installments, net };
    });
  }),
  timeseriesBreakdown: protectedProcedure.input(z4.object({
    from: z4.date(),
    to: z4.date(),
    granularity: z4.enum(["day", "month"]).default("day"),
    clientId: z4.number().optional(),
    projectId: z4.number().optional(),
    invoiceStatuses: z4.array(z4.enum(["draft", "sent", "paid", "cancelled"])).optional(),
    purchaseStatuses: z4.array(z4.enum(["pending", "completed", "cancelled"])).optional(),
    expenseStatuses: z4.array(z4.enum(["active", "cancelled"])).optional(),
    installmentStatuses: z4.array(z4.enum(["pending", "paid", "overdue", "cancelled"])).optional()
  })).query(async ({ input, ctx }) => {
    if (!["admin", "accountant"].includes(ctx.user.role)) {
      throw new TRPCError5({ code: "FORBIDDEN" });
    }
    const conn = await getDb();
    const from = input.from;
    const to = input.to;
    const range = [];
    const cursor = new Date(from);
    const makeKey = (d) => input.granularity === "month" ? `${d.getFullYear()}-${d.getMonth() + 1}` : d.toISOString().substring(0, 10);
    while (cursor <= to) {
      range.push({ key: makeKey(cursor), date: new Date(cursor) });
      if (input.granularity === "month") {
        cursor.setMonth(cursor.getMonth() + 1);
        cursor.setDate(1);
      } else {
        cursor.setDate(cursor.getDate() + 1);
      }
    }
    const invoiceStatuses = input.invoiceStatuses ?? ["draft", "sent", "paid", "cancelled"];
    const purchaseStatuses = input.purchaseStatuses ?? ["pending", "completed", "cancelled"];
    const expenseStatuses = input.expenseStatuses ?? ["active", "cancelled"];
    const installmentStatuses = input.installmentStatuses ?? ["pending", "paid", "overdue", "cancelled"];
    const initInv = Object.fromEntries(invoiceStatuses.map((s) => [s, 0]));
    const initPur = Object.fromEntries(purchaseStatuses.map((s) => [s, 0]));
    const initExp = Object.fromEntries(expenseStatuses.map((s) => [s, 0]));
    const initInst = Object.fromEntries(installmentStatuses.map((s) => [s, 0]));
    const acc = {};
    range.forEach((r) => {
      acc[r.key] = { invoices: { ...initInv }, purchases: { ...initPur }, expenses: { ...initExp }, installments: { ...initInst } };
    });
    if (!conn) {
      return range.map((r) => ({ dateKey: r.key, invoices: { ...initInv }, purchases: { ...initPur } }));
    }
    const invWhere = [gte3(invoices.issueDate, from), lte3(invoices.issueDate, to)];
    if (input.clientId) invWhere.push(sql3`${invoices.clientId} = ${input.clientId}`);
    if (input.projectId) invWhere.push(sql3`${invoices.projectId} = ${input.projectId}`);
    const invRows = await conn.select().from(invoices).where(and4(...invWhere));
    invRows.forEach((r) => {
      const d = new Date(r.issueDate);
      const key = makeKey(d);
      const st = r.status;
      if (acc[key] && invoiceStatuses.includes(st)) {
        acc[key].invoices[st] = (acc[key].invoices[st] || 0) + Number(r.total || 0);
      }
    });
    const purWhere = [gte3(purchases.purchaseDate, from), lte3(purchases.purchaseDate, to)];
    if (input.projectId) purWhere.push(sql3`${purchases.projectId} = ${input.projectId}`);
    const purRows = await conn.select().from(purchases).where(and4(...purWhere));
    purRows.forEach((r) => {
      const d = new Date(r.purchaseDate);
      const key = makeKey(d);
      const st = r.status;
      if (acc[key] && purchaseStatuses.includes(st)) {
        acc[key].purchases[st] = (acc[key].purchases[st] || 0) + Number(r.amount || 0);
      }
    });
    const expWhere = [gte3(expenses.expenseDate, from), lte3(expenses.expenseDate, to)];
    if (input.projectId) expWhere.push(sql3`${expenses.projectId} = ${input.projectId}`);
    const expRows = await conn.select().from(expenses).where(and4(...expWhere));
    expRows.forEach((r) => {
      const d = new Date(r.expenseDate);
      const key = makeKey(d);
      const st = r.status;
      if (acc[key] && expenseStatuses.includes(st)) {
        acc[key].expenses[st] = (acc[key].expenses[st] || 0) + Number(r.amount || 0);
      }
    });
    const instWhere = [gte3(installments.createdAt, from), lte3(installments.createdAt, to)];
    if (input.projectId) instWhere.push(sql3`${installments.projectId} = ${input.projectId}`);
    const instRows = await conn.select().from(installments).where(and4(...instWhere));
    instRows.forEach((r) => {
      const d = new Date(r.createdAt);
      const key = makeKey(d);
      const st = r.status;
      if (acc[key] && installmentStatuses.includes(st)) {
        acc[key].installments[st] = (acc[key].installments[st] || 0) + Number(r.amount || 0);
      }
    });
    return range.map((r) => ({ dateKey: r.key, invoices: acc[r.key].invoices, purchases: acc[r.key].purchases, expenses: acc[r.key].expenses, installments: acc[r.key].installments }));
  })
});

// server/routers/tasks.ts
import { z as z5 } from "zod";
import { TRPCError as TRPCError6 } from "@trpc/server";
init_demoStore();
init_schema();
import { and as and5, eq as eq4, gte as gte4, lte as lte4 } from "drizzle-orm";
async function ensureTasksPerm(ctx) {
  const role = ctx.user.role;
  const allowedRoles = [
    "admin",
    "project_manager",
    "designer",
    "site_engineer",
    "planning_engineer",
    "architect",
    "interior_designer",
    "hr_manager"
  ];
  if (!allowedRoles.includes(role)) {
    throw new TRPCError6({ code: "FORBIDDEN", message: "\u0644\u0627 \u062A\u0645\u0644\u0643 \u0635\u0644\u0627\u062D\u064A\u0629 \u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0645\u0647\u0627\u0645" });
  }
}
var tasksRouter = router({
  getById: protectedProcedure.input(z5.object({ id: z5.number() })).query(async ({ input, ctx }) => {
    await ensureTasksPerm(ctx);
    const conn = await getDb();
    if (!conn) {
      const tasks = list("projectTasks");
      const task2 = tasks.find((t2) => t2.id === input.id);
      if (!task2) throw new TRPCError6({ code: "NOT_FOUND" });
      const children2 = tasks.filter((t2) => t2.parentId === input.id);
      const comments2 = list("taskComments").filter((c) => c.taskId === input.id);
      return { task: task2, children: children2, comments: comments2 };
    }
    const rows = await conn.select().from(projectTasks).where(eq4(projectTasks.id, input.id)).limit(1);
    const task = rows[0];
    if (!task) throw new TRPCError6({ code: "NOT_FOUND" });
    const children = await conn.select().from(projectTasks).where(eq4(projectTasks.parentId, input.id));
    const comments = await conn.select().from(taskComments).where(eq4(taskComments.taskId, input.id));
    return { task, children, comments };
  }),
  list: protectedProcedure.input(z5.object({
    projectId: z5.number().optional(),
    from: z5.date().optional(),
    to: z5.date().optional(),
    status: z5.enum(["planned", "in_progress", "done", "cancelled"]).optional(),
    assignedTo: z5.number().optional()
  }).optional()).query(async ({ input }) => {
    const conn = await getDb();
    if (!conn) {
      let tasks = list("projectTasks");
      if (input?.projectId) tasks = tasks.filter((t2) => t2.projectId === input.projectId);
      if (input?.status) tasks = tasks.filter((t2) => t2.status === input.status);
      if (input?.assignedTo) tasks = tasks.filter((t2) => t2.assignedTo === input.assignedTo);
      return tasks;
    }
    const whereClauses = [];
    if (input?.projectId) whereClauses.push(eq4(projectTasks.projectId, input.projectId));
    if (input?.from) whereClauses.push(gte4(projectTasks.createdAt, input.from));
    if (input?.to) whereClauses.push(lte4(projectTasks.createdAt, input.to));
    if (input?.status) whereClauses.push(eq4(projectTasks.status, input.status));
    if (input?.assignedTo) whereClauses.push(eq4(projectTasks.assignedTo, input.assignedTo));
    const where = whereClauses.length ? and5(...whereClauses) : void 0;
    const rows = where ? await conn.select().from(projectTasks).where(where) : await conn.select().from(projectTasks);
    return rows;
  }),
  create: protectedProcedure.input(z5.object({
    projectId: z5.number(),
    name: z5.string(),
    description: z5.string().optional(),
    startDate: z5.date().optional(),
    endDate: z5.date().optional(),
    assignedTo: z5.number().optional(),
    priority: z5.enum(["low", "medium", "high", "critical"]).optional(),
    estimateHours: z5.number().min(0).optional(),
    progress: z5.number().min(0).max(100).optional(),
    parentId: z5.number().optional(),
    status: z5.enum(["planned", "in_progress", "done", "cancelled"]).default("planned")
  })).mutation(async ({ input, ctx }) => {
    await ensureTasksPerm(ctx);
    const conn = await getDb();
    if (!conn) {
      const rec = insert("projectTasks", {
        projectId: input.projectId,
        name: input.name,
        description: input.description ?? null,
        startDate: input.startDate ?? null,
        endDate: input.endDate ?? null,
        assignedTo: input.assignedTo ?? null,
        status: input.status,
        priority: input.priority ?? "medium",
        estimateHours: input.estimateHours ?? null,
        progress: input.progress ?? 0,
        parentId: input.parentId ?? null,
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date()
      });
      return { success: true, id: rec.id };
    }
    await conn.insert(projectTasks).values({
      projectId: input.projectId,
      name: input.name,
      description: input.description ?? null,
      startDate: input.startDate ?? null,
      endDate: input.endDate ?? null,
      assignedTo: input.assignedTo ?? null,
      status: input.status,
      priority: input.priority ?? "medium",
      estimateHours: input.estimateHours ?? null,
      progress: input.progress ?? 0,
      parentId: input.parentId ?? null,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    });
    await createAuditLog({ userId: ctx.user.id, action: "CREATE_TASK", entityType: "task", details: `Task: ${input.name}` });
    return { success: true };
  }),
  update: protectedProcedure.input(z5.object({
    id: z5.number(),
    name: z5.string().optional(),
    description: z5.string().optional(),
    startDate: z5.date().optional(),
    endDate: z5.date().optional(),
    assignedTo: z5.number().optional(),
    status: z5.enum(["planned", "in_progress", "done", "cancelled"]).optional(),
    priority: z5.enum(["low", "medium", "high", "critical"]).optional(),
    estimateHours: z5.number().min(0).optional(),
    progress: z5.number().min(0).max(100).optional(),
    parentId: z5.number().optional()
  })).mutation(async ({ input, ctx }) => {
    await ensureTasksPerm(ctx);
    const conn = await getDb();
    if (!conn) {
      const updates2 = { updatedAt: /* @__PURE__ */ new Date() };
      if (input.name !== void 0) updates2.name = input.name;
      if (input.description !== void 0) updates2.description = input.description;
      if (input.startDate !== void 0) updates2.startDate = input.startDate;
      if (input.endDate !== void 0) updates2.endDate = input.endDate;
      if (input.assignedTo !== void 0) updates2.assignedTo = input.assignedTo;
      if (input.status !== void 0) updates2.status = input.status;
      if (input.priority !== void 0) updates2.priority = input.priority;
      if (input.estimateHours !== void 0) updates2.estimateHours = input.estimateHours;
      if (input.progress !== void 0) updates2.progress = input.progress;
      if (input.parentId !== void 0) updates2.parentId = input.parentId;
      update("projectTasks", input.id, updates2);
      return { success: true };
    }
    const updates = { updatedAt: /* @__PURE__ */ new Date() };
    if (input.name !== void 0) updates.name = input.name;
    if (input.description !== void 0) updates.description = input.description;
    if (input.startDate !== void 0) updates.startDate = input.startDate;
    if (input.endDate !== void 0) updates.endDate = input.endDate;
    if (input.assignedTo !== void 0) updates.assignedTo = input.assignedTo;
    if (input.status !== void 0) updates.status = input.status;
    if (input.priority !== void 0) updates.priority = input.priority;
    if (input.estimateHours !== void 0) updates.estimateHours = input.estimateHours;
    if (input.progress !== void 0) updates.progress = input.progress;
    if (input.parentId !== void 0) updates.parentId = input.parentId;
    const current = await conn.select().from(projectTasks).where(eq4(projectTasks.id, input.id)).limit(1);
    await conn.update(projectTasks).set(updates).where(eq4(projectTasks.id, input.id));
    const prev = current[0];
    if (prev) {
      if (input.status && input.status !== prev.status) {
        await notifyOwner({ title: "\u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0645\u0647\u0645\u0629", content: `\u062A\u0645 \u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0627\u0644\u0645\u0647\u0645\u0629 "${prev.name}" \u0625\u0644\u0649 ${input.status}` }).catch(() => {
        });
      }
      if (input.assignedTo !== void 0 && input.assignedTo !== prev.assignedTo) {
        await notifyOwner({ title: "\u062A\u0639\u064A\u064A\u0646 \u0645\u0633\u0624\u0648\u0644 \u0645\u0647\u0645\u0629", content: `\u062A\u0645 \u062A\u0639\u064A\u064A\u0646/\u062A\u063A\u064A\u064A\u0631 \u0645\u0633\u0624\u0648\u0644 \u0627\u0644\u0645\u0647\u0645\u0629 "${prev.name}"` }).catch(() => {
        });
      }
    }
    await createAuditLog({ userId: ctx.user.id, action: "UPDATE_TASK", entityType: "task", entityId: input.id, details: `Updated task` });
    return { success: true };
  }),
  delete: protectedProcedure.input(z5.object({ id: z5.number() })).mutation(async ({ input, ctx }) => {
    await ensureTasksPerm(ctx);
    const conn = await getDb();
    if (!conn) {
      remove("projectTasks", input.id);
      return { success: true };
    }
    await conn.delete(projectTasks).where(eq4(projectTasks.id, input.id));
    await createAuditLog({ userId: ctx.user.id, action: "DELETE_TASK", entityType: "task", entityId: input.id, details: `Deleted task` });
    return { success: true };
  }),
  comments: router({
    list: protectedProcedure.input(z5.object({ taskId: z5.number() })).query(async ({ input, ctx }) => {
      await ensureTasksPerm(ctx);
      const conn = await getDb();
      if (!conn) return [];
      return await conn.select().from(taskComments).where(eq4(taskComments.taskId, input.taskId));
    }),
    add: protectedProcedure.input(z5.object({ taskId: z5.number(), content: z5.string().min(1) })).mutation(async ({ input, ctx }) => {
      await ensureTasksPerm(ctx);
      const conn = await getDb();
      if (!conn) throw new TRPCError6({ code: "INTERNAL_SERVER_ERROR" });
      await conn.insert(taskComments).values({
        taskId: input.taskId,
        content: input.content,
        createdBy: ctx.user.id,
        createdAt: /* @__PURE__ */ new Date()
      });
      await createAuditLog({ userId: ctx.user.id, action: "ADD_TASK_COMMENT", entityType: "task", entityId: input.taskId, details: `Comment added` });
      return { success: true };
    }),
    delete: protectedProcedure.input(z5.object({ id: z5.number() })).mutation(async ({ input, ctx }) => {
      await ensureTasksPerm(ctx);
      const conn = await getDb();
      if (!conn) throw new TRPCError6({ code: "INTERNAL_SERVER_ERROR" });
      await conn.delete(taskComments).where(eq4(taskComments.id, input.id));
      await createAuditLog({ userId: ctx.user.id, action: "DELETE_TASK_COMMENT", entityType: "task", entityId: input.id, details: `Comment deleted` });
      return { success: true };
    })
  })
});

// server/routers.ts
init_schema();
import { gte as gte5, eq as eq5, desc as desc4 } from "drizzle-orm";
function generateUniqueNumber(prefix) {
  const timestamp2 = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 7);
  return `${prefix}-${timestamp2}-${random}`.toUpperCase();
}
async function logAudit(userId, action, entityType, entityId, details, ipAddress) {
  await createAuditLog({
    userId,
    action,
    entityType,
    entityId,
    details,
    ipAddress
  });
}
async function ensurePerm(ctx, sectionKey) {
  if (false) {
    return;
  }
  const role = ctx.user.role;
  const allowedByRole = {
    admin: ["*"],
    finance_manager: ["accounting", "reports"],
    accountant: ["accounting", "reports"],
    project_manager: ["projects", "projectTasks", "rfis", "submittals", "drawings", "projectReports"],
    site_engineer: ["projects", "projectTasks", "rfis", "submittals", "drawings"],
    planning_engineer: ["projects", "projectTasks", "projectReports"],
    procurement_officer: ["procurement", "purchases", "boq", "projectReports"],
    qa_qc: ["qaqc", "submittals", "rfis"],
    document_controller: ["documents", "drawings", "submittals", "attachments"],
    architect: ["projects", "drawings", "rfis", "submittals"],
    interior_designer: ["projects", "drawings"],
    designer: ["projects", "projectTasks"],
    sales_manager: ["sales", "clients", "invoices"],
    hr_manager: ["hr"],
    storekeeper: ["procurement"],
    viewer: []
  };
  const allowedList = allowedByRole[role] || [];
  const roleAllowed = allowedList.includes("*") || allowedList.includes(sectionKey);
  if (!roleAllowed) {
    throw new TRPCError7({ code: "FORBIDDEN", message: "Section access denied" });
  }
  const perms = await getUserPermissions(ctx.user.id);
  const record = perms?.permissionsJson ? JSON.parse(perms.permissionsJson) : {};
  if (record.hasOwnProperty(sectionKey) && !record[sectionKey]) {
    throw new TRPCError7({ code: "FORBIDDEN", message: "Section access denied" });
  }
}
var adminProcedure3 = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError7({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});
var accountantProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!["admin", "accountant", "finance_manager"].includes(ctx.user.role)) {
    throw new TRPCError7({ code: "FORBIDDEN", message: "Accountant access required" });
  }
  return next({ ctx });
});
var managerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!["admin", "project_manager", "site_engineer", "architect", "interior_designer", "planning_engineer", "designer"].includes(ctx.user.role)) {
    throw new TRPCError7({ code: "FORBIDDEN", message: "Project manager access required" });
  }
  return next({ ctx });
});
var appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      if (ctx.user) {
        logAudit(ctx.user.id, "LOGOUT", "user", ctx.user.id);
      }
      return { success: true };
    }),
    health: publicProcedure.query(() => {
      return {
        hasCookieSecret: Boolean(process.env.COOKIE_SECRET || process.env.JWT_SECRET),
        hasOAuthServerUrl: Boolean(process.env.OAUTH_SERVER_URL),
        serverOriginSet: Boolean(process.env.VITE_SERVER_ORIGIN),
        isProduction: true
      };
    })
  }),
  // ============= CLIENTS =============
  clients: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "clients");
      return await getAllClients();
    }),
    getById: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "clients");
      const client = await getClientById(input.id);
      if (!client) throw new TRPCError7({ code: "NOT_FOUND" });
      const [projects2, invoices2, forms2] = await Promise.all([
        getClientProjects(input.id),
        getClientInvoices(input.id),
        getClientForms(input.id)
      ]);
      return { client, projects: projects2, invoices: invoices2, forms: forms2 };
    }),
    create: protectedProcedure.input(z6.object({
      name: z6.string(),
      email: z6.string().email().optional(),
      phone: z6.string().optional(),
      address: z6.string().optional(),
      city: z6.string().optional(),
      notes: z6.string().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "clients");
      const clientNumber = generateUniqueNumber("CLT");
      await createClient({
        ...input,
        clientNumber,
        createdBy: ctx.user.id
      });
      await logAudit(ctx.user.id, "CREATE_CLIENT", "client", void 0, `Created client: ${input.name}`);
      return { success: true, clientNumber };
    }),
    update: protectedProcedure.input(z6.object({
      id: z6.number(),
      name: z6.string().optional(),
      email: z6.string().email().optional(),
      phone: z6.string().optional(),
      address: z6.string().optional(),
      city: z6.string().optional(),
      notes: z6.string().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "clients");
      const { id, ...data } = input;
      await updateClient(id, data);
      await logAudit(ctx.user.id, "UPDATE_CLIENT", "client", id, `Updated client`);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "clients");
      await deleteClient(input.id);
      await logAudit(ctx.user.id, "DELETE_CLIENT", "client", input.id);
      return { success: true };
    })
  }),
  // ============= PROJECTS =============
  projects: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "projects");
      return await getAllProjects();
    }),
    getById: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const project = await getProjectById(input.id);
      if (!project) throw new TRPCError7({ code: "NOT_FOUND" });
      const [client, boqItems, expenses2, installments2] = await Promise.all([
        getClientById(project.clientId),
        getProjectBOQ(input.id),
        getProjectExpenses(input.id),
        getProjectInstallments(input.id)
      ]);
      return { project, client, boqItems, expenses: expenses2, installments: installments2 };
    }),
    create: managerProcedure.input(z6.object({
      clientId: z6.number(),
      name: z6.string(),
      description: z6.string().optional(),
      startDate: z6.date().optional(),
      endDate: z6.date().optional(),
      budget: z6.number().optional(),
      assignedTo: z6.number().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const projectNumber = generateUniqueNumber("PRJ");
      await createProject({
        ...input,
        projectNumber,
        createdBy: ctx.user.id
      });
      await logAudit(ctx.user.id, "CREATE_PROJECT", "project", void 0, `Created project: ${input.name}`);
      return { success: true, projectNumber };
    }),
    update: managerProcedure.input(z6.object({
      id: z6.number(),
      name: z6.string().optional(),
      description: z6.string().optional(),
      status: z6.enum(["design", "execution", "delivery", "completed", "cancelled"]).optional(),
      startDate: z6.date().optional(),
      endDate: z6.date().optional(),
      budget: z6.number().optional(),
      assignedTo: z6.number().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const { id, ...data } = input;
      await updateProject(id, data);
      await logAudit(ctx.user.id, "UPDATE_PROJECT", "project", id);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      await deleteProject(input.id);
      await logAudit(ctx.user.id, "DELETE_PROJECT", "project", input.id);
      return { success: true };
    }),
    getDetails: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const project = await getProjectById(input.id);
      if (!project) throw new TRPCError7({ code: "NOT_FOUND", message: "Project not found" });
      const [boq2, expenses2, installments2] = await Promise.all([
        getProjectBOQ(input.id),
        getProjectExpenses(input.id),
        getProjectInstallments(input.id)
      ]);
      return { project, boq: boq2, expenses: expenses2, installments: installments2 };
    }),
    createTask: protectedProcedure.input(z6.object({
      projectId: z6.number(),
      name: z6.string(),
      description: z6.string().optional(),
      startDate: z6.date().optional(),
      endDate: z6.date().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      await createProjectTask({
        projectId: input.projectId,
        name: input.name,
        description: input.description,
        startDate: input.startDate,
        endDate: input.endDate,
        status: "planned"
      });
      await logAudit(ctx.user.id, "CREATE_TASK", "project", input.projectId, `Task: ${input.name}`);
      return { success: true };
    }),
    listTasks: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      return await getProjectTasks(input.projectId);
    }),
    deleteTask: protectedProcedure.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      await deleteProjectTask(input.id);
      await logAudit(ctx.user.id, "DELETE_TASK", "task", input.id);
      return { success: true };
    })
  }),
  rfi: router({
    list: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) return [];
      const { rfis: rfis2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      return await conn.select().from(rfis2).where(eq5(rfis2.projectId, input.projectId)).orderBy(desc4(rfis2.submittedAt));
    }),
    create: protectedProcedure.input(z6.object({ projectId: z6.number(), title: z6.string(), question: z6.string() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { rfis: rfis2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const rfiNumber = generateUniqueNumber("RFI");
      await conn.insert(rfis2).values({
        projectId: input.projectId,
        rfiNumber,
        title: input.title,
        question: input.question,
        status: "open",
        submittedBy: ctx.user.id
      });
      await logAudit(ctx.user.id, "CREATE_RFI", "project", input.projectId, rfiNumber);
      return { success: true, rfiNumber };
    }),
    answer: protectedProcedure.input(z6.object({ id: z6.number(), answer: z6.string() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { rfis: rfis2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.update(rfis2).set({ answer: input.answer, answeredBy: ctx.user.id, answeredAt: /* @__PURE__ */ new Date(), status: "answered" }).where(eq5(rfis2.id, input.id));
      await logAudit(ctx.user.id, "ANSWER_RFI", "rfi", input.id);
      return { success: true };
    }),
    close: protectedProcedure.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { rfis: rfis2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.update(rfis2).set({ status: "closed" }).where(eq5(rfis2.id, input.id));
      await logAudit(ctx.user.id, "CLOSE_RFI", "rfi", input.id);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { rfis: rfis2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.delete(rfis2).where(eq5(rfis2.id, input.id));
      await logAudit(ctx.user.id, "DELETE_RFI", "rfi", input.id);
      return { success: true };
    })
  }),
  submittals: router({
    list: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) return [];
      const { submittals: submittals2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      return await conn.select().from(submittals2).where(eq5(submittals2.projectId, input.projectId)).orderBy(desc4(submittals2.submittedAt));
    }),
    create: protectedProcedure.input(z6.object({ projectId: z6.number(), title: z6.string() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { submittals: submittals2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const code = generateUniqueNumber("SUB");
      await conn.insert(submittals2).values({
        projectId: input.projectId,
        submittalCode: code,
        title: input.title,
        status: "submitted",
        submittedBy: ctx.user.id
      });
      await logAudit(ctx.user.id, "CREATE_SUBMITTAL", "project", input.projectId, code);
      return { success: true, code };
    }),
    approve: protectedProcedure.input(z6.object({ id: z6.number(), notes: z6.string().optional() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { submittals: submittals2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.update(submittals2).set({ status: "approved", approvedBy: ctx.user.id, approvedAt: /* @__PURE__ */ new Date(), notes: input.notes }).where(eq5(submittals2.id, input.id));
      await logAudit(ctx.user.id, "APPROVE_SUBMITTAL", "submittal", input.id);
      return { success: true };
    }),
    reject: protectedProcedure.input(z6.object({ id: z6.number(), notes: z6.string().optional() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { submittals: submittals2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.update(submittals2).set({ status: "rejected", approvedBy: ctx.user.id, approvedAt: /* @__PURE__ */ new Date(), notes: input.notes }).where(eq5(submittals2.id, input.id));
      await logAudit(ctx.user.id, "REJECT_SUBMITTAL", "submittal", input.id);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { submittals: submittals2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.delete(submittals2).where(eq5(submittals2.id, input.id));
      await logAudit(ctx.user.id, "DELETE_SUBMITTAL", "submittal", input.id);
      return { success: true };
    })
  }),
  drawings: router({
    list: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) return [];
      const { drawings: drawings2, drawingVersions: drawingVersions2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const rows = await conn.select().from(drawings2).where(eq5(drawings2.projectId, input.projectId)).orderBy(desc4(drawings2.createdAt));
      return rows;
    }),
    create: protectedProcedure.input(z6.object({ projectId: z6.number(), drawingCode: z6.string(), title: z6.string(), discipline: z6.string().optional() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { drawings: drawings2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.insert(drawings2).values({
        projectId: input.projectId,
        drawingCode: input.drawingCode,
        title: input.title,
        discipline: input.discipline,
        status: "draft"
      });
      await logAudit(ctx.user.id, "CREATE_DRAWING", "project", input.projectId, input.drawingCode);
      return { success: true };
    }),
    addVersion: protectedProcedure.input(z6.object({ drawingId: z6.number(), version: z6.string(), fileUrl: z6.string(), notes: z6.string().optional() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { drawingVersions: drawingVersions2, drawings: drawings2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const res = await conn.insert(drawingVersions2).values({
        drawingId: input.drawingId,
        version: input.version,
        fileUrl: input.fileUrl,
        notes: input.notes,
        createdBy: ctx.user.id
      });
      const [latest] = await conn.select().from(drawingVersions2).where(eq5(drawingVersions2.drawingId, input.drawingId)).orderBy(desc4(drawingVersions2.createdAt)).limit(1);
      if (latest) {
        await conn.update(drawings2).set({ currentVersionId: latest.id, status: "issued" }).where(eq5(drawings2.id, input.drawingId));
      }
      await logAudit(ctx.user.id, "ADD_DRAWING_VERSION", "drawing", input.drawingId, input.version);
      return { success: true };
    }),
    versions: protectedProcedure.input(z6.object({ drawingId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) return [];
      const { drawingVersions: drawingVersions2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      return await conn.select().from(drawingVersions2).where(eq5(drawingVersions2.drawingId, input.drawingId)).orderBy(desc4(drawingVersions2.createdAt));
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) throw new TRPCError7({ code: "INTERNAL_SERVER_ERROR" });
      const { drawings: drawings2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await conn.delete(drawings2).where(eq5(drawings2.id, input.id));
      await logAudit(ctx.user.id, "DELETE_DRAWING", "drawing", input.id);
      return { success: true };
    })
  }),
  projectReports: router({
    baselineVsActual: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const tasks = await getProjectTasks(input.projectId);
      const now = /* @__PURE__ */ new Date();
      let plannedSum = 0;
      let plannedCount = 0;
      let actualSum = 0;
      let actualCount = 0;
      tasks.forEach((t2) => {
        if (t2.startDate && t2.endDate) {
          plannedCount++;
          const start = new Date(t2.startDate).getTime();
          const end = new Date(t2.endDate).getTime();
          const total = Math.max(end - start, 1);
          const elapsed = Math.max(Math.min(now.getTime() - start, total), 0);
          const planned = Math.min(Math.round(elapsed / total * 100), 100);
          plannedSum += planned;
        }
        actualCount++;
        const actual = typeof t2.progress === "number" ? t2.progress : t2.status === "done" ? 100 : t2.status === "in_progress" ? 50 : 0;
        actualSum += actual;
      });
      const plannedPercent = plannedCount > 0 ? Math.round(plannedSum / plannedCount) : 0;
      const actualPercent = actualCount > 0 ? Math.round(actualSum / actualCount) : 0;
      const variance = actualPercent - plannedPercent;
      return { plannedPercent, actualPercent, variance };
    }),
    procurementTracker: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const conn = await getDb();
      if (!conn) return [];
      const { boq: boq2, purchases: purchases2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const items = await conn.select().from(boq2).where(eq5(boq2.projectId, input.projectId));
      const orders = await conn.select().from(purchases2).where(eq5(purchases2.projectId, input.projectId));
      const rows = items.map((it) => {
        const totalCost = Number(it.total || 0);
        const ordered = orders.filter((o) => (o.description || "").toLowerCase().includes((it.itemName || "").toLowerCase())).reduce((sum2, o) => sum2 + Number(o.amount || 0), 0);
        const status = ordered <= 0 ? "not_ordered" : ordered < totalCost ? "partial" : "ordered";
        return { itemName: it.itemName, totalCost, ordered, status };
      });
      return rows;
    })
  }),
  // ============= INVOICES =============
  invoices: router({
    list: protectedProcedure.input(z6.object({ type: z6.enum(["invoice", "quote"]).optional() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "invoices");
      const allInvoices = await getAllInvoices();
      if (input.type) {
        return allInvoices.filter((inv) => inv.type === input.type);
      }
      return allInvoices;
    }),
    getById: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "invoices");
      const invoice = await getInvoiceById(input.id);
      if (!invoice) throw new TRPCError7({ code: "NOT_FOUND" });
      const [client, items] = await Promise.all([
        getClientById(invoice.clientId),
        getInvoiceItems(input.id)
      ]);
      return { invoice, client, items };
    }),
    create: protectedProcedure.input(z6.object({
      type: z6.enum(["invoice", "quote"]),
      clientId: z6.number(),
      projectId: z6.number().optional(),
      issueDate: z6.date(),
      dueDate: z6.date().optional(),
      subtotal: z6.number(),
      tax: z6.number().optional(),
      discount: z6.number().optional(),
      total: z6.number(),
      notes: z6.string().optional(),
      terms: z6.string().optional(),
      formData: z6.string().optional(),
      items: z6.array(z6.object({
        description: z6.string(),
        quantity: z6.number(),
        unitPrice: z6.number(),
        total: z6.number()
      }))
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "invoices");
      const invoiceNumber = generateUniqueNumber(input.type === "invoice" ? "INV" : "QUO");
      const { items, ...invoiceData } = input;
      const result = await createInvoice({
        ...invoiceData,
        invoiceNumber,
        createdBy: ctx.user.id
      });
      const invoiceId = Number(result.insertId);
      if (invoiceId && !isNaN(invoiceId)) {
        for (let i = 0; i < items.length; i++) {
          await createInvoiceItem({
            invoiceId,
            ...items[i],
            sortOrder: i
          });
        }
      }
      await logAudit(ctx.user.id, "CREATE_INVOICE", "invoice", invoiceId, `Created ${input.type}: ${invoiceNumber}`);
      await notifyOwner({
        title: `${input.type === "invoice" ? "\u0641\u0627\u062A\u0648\u0631\u0629 \u062C\u062F\u064A\u062F\u0629" : "\u0639\u0631\u0636 \u0633\u0639\u0631 \u062C\u062F\u064A\u062F"}`,
        content: `\u062A\u0645 \u0625\u0646\u0634\u0627\u0621 ${input.type === "invoice" ? "\u0641\u0627\u062A\u0648\u0631\u0629" : "\u0639\u0631\u0636 \u0633\u0639\u0631"} \u0631\u0642\u0645 ${invoiceNumber} \u0628\u0645\u0628\u0644\u063A ${input.total} \u0631\u064A\u0627\u0644`
      });
      const createdInvoice = await getInvoiceById(invoiceId);
      return createdInvoice || { id: invoiceId, invoiceNumber, type: input.type, total: input.total };
    }),
    update: protectedProcedure.input(z6.object({
      id: z6.number(),
      status: z6.enum(["draft", "sent", "paid", "cancelled"]).optional(),
      notes: z6.string().optional(),
      formData: z6.string().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "invoices");
      const { id, ...data } = input;
      await updateInvoice(id, data);
      await logAudit(ctx.user.id, "UPDATE_INVOICE", "invoice", id);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "invoices");
      await deleteInvoice(input.id);
      await logAudit(ctx.user.id, "DELETE_INVOICE", "invoice", input.id);
      return { success: true };
    })
  }),
  // ============= CHANGE ORDERS =============
  changeOrders: router({
    listByProject: protectedProcedure.input(z6.object({ projectId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      return await getProjectChangeOrders(input.projectId);
    }),
    getById: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const co = await getChangeOrderById(input.id);
      if (!co) throw new TRPCError7({ code: "NOT_FOUND" });
      const project = await getProjectById(co.projectId);
      return { changeOrder: co, project };
    }),
    create: managerProcedure.input(z6.object({
      projectId: z6.number(),
      title: z6.string(),
      description: z6.string().optional(),
      origin: z6.enum(["client", "internal", "site"]).optional(),
      impactCost: z6.number().min(0).default(0),
      impactDays: z6.number().min(0).default(0)
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      const code = generateUniqueNumber("CO");
      const result = await createChangeOrder({
        projectId: input.projectId,
        code,
        title: input.title,
        description: input.description,
        origin: input.origin || "client",
        status: "draft",
        impactCost: input.impactCost,
        impactDays: input.impactDays,
        createdBy: ctx.user.id
      });
      const id = Number(result?.insertId) || void 0;
      await logAudit(ctx.user.id, "CREATE_CHANGE_ORDER", "changeOrder", id, `CO ${code}`);
      return { success: true, id, code };
    }),
    submit: managerProcedure.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      await updateChangeOrder(input.id, { status: "submitted", submittedBy: ctx.user.id, submittedAt: /* @__PURE__ */ new Date() });
      await logAudit(ctx.user.id, "SUBMIT_CHANGE_ORDER", "changeOrder", input.id);
      return { success: true };
    }),
    approve: protectedProcedure.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      if (!["admin", "accountant", "project_manager"].includes(ctx.user.role)) {
        throw new TRPCError7({ code: "FORBIDDEN", message: "Approval access required" });
      }
      await ensurePerm(ctx, "projects");
      await updateChangeOrder(input.id, { status: "approved", approvedBy: ctx.user.id, approvedAt: /* @__PURE__ */ new Date() });
      await logAudit(ctx.user.id, "APPROVE_CHANGE_ORDER", "changeOrder", input.id);
      return { success: true };
    }),
    reject: protectedProcedure.input(z6.object({ id: z6.number(), reason: z6.string().min(2) })).mutation(async ({ input, ctx }) => {
      if (!["admin", "accountant", "project_manager"].includes(ctx.user.role)) {
        throw new TRPCError7({ code: "FORBIDDEN", message: "Approval access required" });
      }
      await ensurePerm(ctx, "projects");
      await updateChangeOrder(input.id, { status: "rejected", rejectedBy: ctx.user.id, rejectedAt: /* @__PURE__ */ new Date(), rejectionReason: input.reason });
      await logAudit(ctx.user.id, "REJECT_CHANGE_ORDER", "changeOrder", input.id, input.reason);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "projects");
      await deleteChangeOrder(input.id);
      await logAudit(ctx.user.id, "DELETE_CHANGE_ORDER", "changeOrder", input.id);
      return { success: true };
    })
  }),
  // ============= FORMS =============
  forms: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "forms");
      return await getAllForms();
    }),
    getById: protectedProcedure.input(z6.object({ id: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "forms");
      const form = await getFormById(input.id);
      if (!form) throw new TRPCError7({ code: "NOT_FOUND" });
      const client = await getClientById(form.clientId);
      return { form, client };
    }),
    create: protectedProcedure.input(z6.object({
      clientId: z6.number(),
      projectId: z6.number().optional(),
      formType: z6.string(),
      formData: z6.string()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "forms");
      const formNumber = generateUniqueNumber("FRM");
      const result = await createForm({
        ...input,
        formNumber,
        createdBy: ctx.user.id
      });
      let formId = Number(result?.insertId);
      if (!formId || isNaN(formId)) {
        const all = await getAllForms();
        const match = all.find((f) => f.formNumber === formNumber);
        formId = Number(match?.id) || void 0;
      }
      await logAudit(ctx.user.id, "CREATE_FORM", "form", formId, `Created form: ${formNumber}`);
      await notifyOwner({
        title: "\u0627\u0633\u062A\u0645\u0627\u0631\u0629 \u0639\u0645\u064A\u0644 \u062C\u062F\u064A\u062F\u0629",
        content: `\u062A\u0645 \u0625\u0636\u0627\u0641\u0629 \u0627\u0633\u062A\u0645\u0627\u0631\u0629 \u062C\u062F\u064A\u062F\u0629 \u0631\u0642\u0645 ${formNumber}`
      });
      return { success: true, id: formId, formNumber };
    }),
    update: protectedProcedure.input(z6.object({
      id: z6.number(),
      status: z6.enum(["pending", "reviewed", "approved", "rejected"]).optional(),
      formData: z6.string().optional()
    })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "forms");
      const { id, ...data } = input;
      await updateForm(id, data);
      await logAudit(ctx.user.id, "UPDATE_FORM", "form", id);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "forms");
      await deleteForm(input.id);
      await logAudit(ctx.user.id, "DELETE_FORM", "form", input.id);
      return { success: true };
    })
  }),
  // ============= AUDIT LOGS =============
  auditLogs: router({
    list: adminProcedure3.input(z6.object({ limit: z6.number().optional() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "audit");
      return await getAuditLogs(input.limit);
    }),
    getEntityLogs: protectedProcedure.input(z6.object({ entityType: z6.string(), entityId: z6.number() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "audit");
      return await getEntityAuditLogs(input.entityType, input.entityId);
    })
  }),
  // ============= SETTINGS =============
  settings: router({
    get: adminProcedure3.input(z6.object({ key: z6.string() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "settings");
      return await getCompanySetting(input.key);
    }),
    getAll: adminProcedure3.query(async ({ ctx }) => {
      await ensurePerm(ctx, "settings");
      return await getAllCompanySettings();
    }),
    set: adminProcedure3.input(z6.object({ key: z6.string(), value: z6.string() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "settings");
      await setCompanySetting(input.key, input.value, ctx.user.id);
      await logAudit(ctx.user.id, "UPDATE_SETTING", "setting", void 0, `Updated setting: ${input.key}`);
      return { success: true };
    })
  }),
  // ============= USERS =============
  users: router({
    list: adminProcedure3.query(async () => {
      return await getAllUsers();
    }),
    create: adminProcedure3.input(z6.object({
      name: z6.string(),
      email: z6.string().email(),
      role: z6.enum([
        "admin",
        "accountant",
        "finance_manager",
        "project_manager",
        "site_engineer",
        "planning_engineer",
        "procurement_officer",
        "qa_qc",
        "document_controller",
        "architect",
        "interior_designer",
        "sales_manager",
        "hr_manager",
        "storekeeper",
        "designer",
        "viewer"
      ]).default("designer")
    })).mutation(async ({ input, ctx }) => {
      const existingUser = await getUserByEmail(input.email);
      if (existingUser) {
        throw new TRPCError7({ code: "CONFLICT", message: "Email already exists" });
      }
      const user = await createUser({
        name: input.name,
        email: input.email,
        role: input.role
      });
      await logAudit(ctx.user.id, "CREATE_USER", "user", user.id, `Created user ${input.email} with role ${input.role}`);
      return user;
    }),
    updateRole: adminProcedure3.input(z6.object({
      userId: z6.number(),
      role: z6.enum([
        "admin",
        "accountant",
        "finance_manager",
        "project_manager",
        "site_engineer",
        "planning_engineer",
        "procurement_officer",
        "qa_qc",
        "document_controller",
        "architect",
        "interior_designer",
        "sales_manager",
        "hr_manager",
        "storekeeper",
        "designer",
        "viewer"
      ]).optional()
    })).mutation(async ({ input, ctx }) => {
      const role = input.role ?? "designer";
      await updateUserRole(input.userId, role);
      await logAudit(ctx.user.id, "UPDATE_USER_ROLE", "user", input.userId, `Changed role to ${input.role}`);
      return { success: true };
    }),
    update: adminProcedure3.input(z6.object({
      userId: z6.number(),
      name: z6.string().optional(),
      email: z6.string().email().optional(),
      role: z6.enum([
        "admin",
        "accountant",
        "finance_manager",
        "project_manager",
        "site_engineer",
        "planning_engineer",
        "procurement_officer",
        "qa_qc",
        "document_controller",
        "architect",
        "interior_designer",
        "sales_manager",
        "hr_manager",
        "storekeeper",
        "designer",
        "viewer"
      ]).optional()
    })).mutation(async ({ input, ctx }) => {
      const { userId, ...updateData } = input;
      if (updateData.email) {
        const existingUser = await getUserByEmail(updateData.email);
        if (existingUser && existingUser.id !== userId) {
          throw new TRPCError7({ code: "CONFLICT", message: "Email already exists" });
        }
      }
      await updateUser(userId, updateData);
      await logAudit(ctx.user.id, "UPDATE_USER", "user", userId, `Updated user information`);
      return { success: true };
    }),
    delete: adminProcedure3.input(z6.object({
      userId: z6.number()
    })).mutation(async ({ input, ctx }) => {
      if (input.userId === ctx.user.id) {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "Cannot delete your own account" });
      }
      await deleteUser(input.userId);
      await logAudit(ctx.user.id, "DELETE_USER", "user", input.userId, `Deleted user`);
      return { success: true };
    }),
    getPermissions: adminProcedure3.input(z6.object({ userId: z6.number() })).query(async ({ input }) => {
      const perms = await getUserPermissions(input.userId);
      return perms?.permissionsJson ? JSON.parse(perms.permissionsJson) : {};
    }),
    mePermissions: protectedProcedure.query(async ({ ctx }) => {
      const perms = await getUserPermissions(ctx.user.id);
      return perms?.permissionsJson ? JSON.parse(perms.permissionsJson) : {};
    }),
    setPermissions: adminProcedure3.input(z6.object({
      userId: z6.number(),
      permissions: z6.record(z6.string(), z6.boolean())
    })).mutation(async ({ input, ctx }) => {
      await setUserPermissions(input.userId, input.permissions);
      await logAudit(ctx.user.id, "UPDATE_USER_PERMISSIONS", "user", input.userId, `Updated permissions`);
      return { success: true };
    })
  }),
  // ============= SEARCH =============
  search: router({
    global: protectedProcedure.input(z6.object({ query: z6.string() })).query(async ({ input, ctx }) => {
      await ensurePerm(ctx, "search");
      return await globalSearch(input.query);
    })
  }),
  // ============= DASHBOARD =============
  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "dashboard");
      return await getDashboardStats();
    }),
    projectsByStatus: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "dashboard");
      const projects2 = await getAllProjects();
      return {
        design: projects2.filter((p) => p.status === "design").length,
        execution: projects2.filter((p) => p.status === "execution").length,
        delivery: projects2.filter((p) => p.status === "delivery").length,
        completed: projects2.filter((p) => p.status === "completed").length,
        cancelled: projects2.filter((p) => p.status === "cancelled").length
      };
    }),
    monthlyRevenue: protectedProcedure.query(async ({ ctx }) => {
      await ensurePerm(ctx, "dashboard");
      const months = ["\u064A\u0646\u0627\u064A\u0631", "\u0641\u0628\u0631\u0627\u064A\u0631", "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064A\u0644", "\u0645\u0627\u064A\u0648", "\u064A\u0648\u0646\u064A\u0648", "\u064A\u0648\u0644\u064A\u0648", "\u0623\u063A\u0633\u0637\u0633", "\u0633\u0628\u062A\u0645\u0628\u0631", "\u0623\u0643\u062A\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631", "\u062F\u064A\u0633\u0645\u0628\u0631"];
      const now = /* @__PURE__ */ new Date();
      const start = new Date(now);
      start.setMonth(now.getMonth() - 5);
      start.setDate(1);
      const conn = await getDb();
      if (!conn) {
        return Array.from({ length: 6 }).map((_, idx) => {
          const m = (start.getMonth() + idx) % 12;
          return { month: months[m], revenue: 0, expenses: 0 };
        });
      }
      const invRows = await conn.select().from(invoices).where(gte5(invoices.createdAt, start));
      const expRows = await conn.select().from(expenses).where(gte5(expenses.createdAt, start));
      const acc = {};
      Array.from({ length: 6 }).forEach((_, idx) => {
        const d = new Date(start);
        d.setMonth(start.getMonth() + idx);
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        acc[key] = { revenue: 0, expenses: 0 };
      });
      invRows.forEach((r) => {
        const d = new Date(r.createdAt);
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        if (acc[key]) acc[key].revenue += Number(r.total || 0);
      });
      expRows.forEach((r) => {
        const d = new Date(r.createdAt);
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        if (acc[key]) acc[key].expenses += Number(r.amount || 0);
      });
      return Array.from({ length: 6 }).map((_, idx) => {
        const d = new Date(start);
        d.setMonth(start.getMonth() + idx);
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        const m = d.getMonth();
        const row = acc[key] || { revenue: 0, expenses: 0 };
        return { month: months[m], revenue: row.revenue, expenses: row.expenses };
      });
    })
  }),
  // ============= FILE UPLOAD =============
  files: router({
    upload: protectedProcedure.input(z6.object({
      entityType: z6.string(),
      entityId: z6.number(),
      fileName: z6.string(),
      fileData: z6.string(),
      // base64
      mimeType: z6.string()
    })).mutation(async ({ input, ctx }) => {
      const ALLOWED_TYPES = [
        "image/png",
        "image/jpeg",
        "image/webp",
        "application/pdf",
        "text/plain",
        "text/html",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ];
      const MAX_SIZE = 10 * 1024 * 1024;
      if (!ALLOWED_TYPES.includes(input.mimeType)) {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "\u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D" });
      }
      const safeName = input.fileName.replace(/[^a-zA-Z0-9_.-]/g, "_");
      const section = input.entityType.startsWith("form") ? "forms" : input.entityType.startsWith("invoice") ? "invoices" : input.entityType === "setting" ? "settings" : "settings";
      await ensurePerm(ctx, section);
      let buffer;
      try {
        buffer = Buffer.from(input.fileData, "base64");
      } catch {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "\u0645\u0644\u0641 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D" });
      }
      if (buffer.length > MAX_SIZE) {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641 \u064A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u062D\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D" });
      }
      const head = buffer.subarray(0, 16);
      const isPng = head[0] === 137 && head[1] === 80 && head[2] === 78 && head[3] === 71;
      const isJpeg = head[0] === 255 && head[1] === 216 && head[2] === 255;
      const isWebp = head.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP";
      const isPdf = head.toString("ascii", 0, 4) === "%PDF";
      const isZip = head.toString("ascii", 0, 2) === "PK";
      const isHtml = buffer.toString("utf8", 0, 16).toLowerCase().includes("<!doctype") || buffer.toString("utf8", 0, 16).toLowerCase().includes("<html");
      const isText = input.mimeType === "text/plain";
      const mimeOk = input.mimeType === "image/png" && isPng || input.mimeType === "image/jpeg" && isJpeg || input.mimeType === "image/webp" && isWebp || input.mimeType === "application/pdf" && isPdf || input.mimeType === "text/html" && isHtml || input.mimeType === "text/plain" && isText || input.mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" && isZip || input.mimeType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" && isZip;
      if (!mimeOk) {
        throw new TRPCError7({ code: "BAD_REQUEST", message: "\u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0645\u062D\u062A\u0648\u0649" });
      }
      const fileKey = `${input.entityType}/${input.entityId}/${Date.now()}-${input.fileName}`;
      let url;
      if (process.env.BUILT_IN_FORGE_API_URL && process.env.BUILT_IN_FORGE_API_KEY) {
        const res = await storagePut(`${input.entityType}/${input.entityId}/${Date.now()}-${safeName}`, buffer, input.mimeType);
        url = res.url;
      } else {
        url = `data:${input.mimeType};base64,${input.fileData}`;
      }
      await createAttachment({
        entityType: input.entityType,
        entityId: input.entityId,
        fileName: safeName,
        fileKey,
        fileUrl: url,
        fileSize: buffer.length,
        mimeType: input.mimeType,
        uploadedBy: ctx.user.id
      });
      await logAudit(ctx.user.id, "UPLOAD_FILE", input.entityType, input.entityId, `Uploaded file: ${input.fileName}`);
      return { success: true, url };
    }),
    list: protectedProcedure.input(z6.object({ entityType: z6.string(), entityId: z6.number() })).query(async ({ input }) => {
      return await getEntityAttachments(input.entityType, input.entityId);
    }),
    delete: protectedProcedure.input(z6.object({ id: z6.number() })).mutation(async ({ input, ctx }) => {
      await ensurePerm(ctx, "attachments");
      await deleteAttachment(input.id);
      await logAudit(ctx.user.id, "DELETE_FILE", "attachment", input.id);
      return { success: true };
    })
  }),
  // ============= HUMAN RESOURCES =============
  hr: hrRouter,
  // ============= ACCOUNTING =============
  accounting: accountingRouter,
  reports: reportsRouter,
  tasks: tasksRouter,
  notifications: router({
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return { count: 0 };
    })
  })
});

// server/_core/context.ts
init_demoStore();
async function createContext(opts) {
  let user = null;
  const cookies = opts.req.headers.cookie || "";
  const hasSessionCookie = cookies.includes("GT_SESSION=") && !cookies.includes("GT_SESSION=;");
  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    user = null;
  }
  if (!user && false) {
    const users2 = list("users");
    const admin = users2.find((u) => (u.role || "") === "admin") || users2[0];
    if (admin) {
      user = {
        id: admin.id,
        openId: admin.openId || "dev-admin",
        name: admin.name || "Developer",
        email: admin.email || "admin@example.com",
        role: admin.role || "admin",
        createdAt: /* @__PURE__ */ new Date(),
        updatedAt: /* @__PURE__ */ new Date(),
        loginMethod: "dev",
        lastSignedIn: /* @__PURE__ */ new Date()
      };
    }
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/app.ts
init_demoStore();
import fs2 from "fs";
import path2 from "path";
function createApp() {
  const app = express();
  app.set("trust proxy", 1);
  if (true) {
    if (!process.env.COOKIE_SECRET && !process.env.JWT_SECRET) {
      throw new Error("Security error: COOKIE_SECRET/JWT_SECRET \u0645\u0637\u0644\u0648\u0628 \u0641\u064A \u0627\u0644\u0625\u0646\u062A\u0627\u062C");
    }
    if (!process.env.WEB_ORIGIN) {
      throw new Error("Security error: WEB_ORIGIN is required in production");
    }
  }
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use((req, res, next) => {
    try {
      const configuredOrigin = process.env.WEB_ORIGIN || "";
      const requestOrigin = req.headers.origin;
      let allowedOrigin = configuredOrigin;
      if (!configuredOrigin && false) {
        allowedOrigin = requestOrigin;
      }
      if (allowedOrigin) {
        res.header("Access-Control-Allow-Origin", allowedOrigin);
        res.header("Vary", "Origin");
      }
      res.header("Access-Control-Allow-Credentials", "true");
      res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
      res.header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
      if (req.method === "OPTIONS") {
        res.status(204).end();
        return;
      }
    } catch {
    }
    next();
  });
  app.get("/healthz", (_req, res) => {
    res.status(200).json({
      ok: true,
      env: "production",
      time: (/* @__PURE__ */ new Date()).toISOString()
    });
  });
  try {
    if (!process.env.DATABASE_URL) {
      const users2 = list("users");
      if (users2.length === 0) {
        insert("users", {
          openId: "seed-admin",
          name: "Admin",
          email: "admin@goldentouch.local",
          role: "admin",
          loginMethod: "dev",
          lastSignedIn: /* @__PURE__ */ new Date()
        });
      }
      const hasRequestedAdmin = users2.some((u) => (u.email || "").toLowerCase() === "almalkalhzen@gmail.com");
      if (!hasRequestedAdmin) {
        insert("users", {
          openId: "alm-" + Math.random().toString(36).slice(2),
          name: "System Admin",
          email: "almalkalhzen@gmail.com",
          role: "admin",
          loginMethod: "dev",
          lastSignedIn: /* @__PURE__ */ new Date()
        });
      }
      const hasPMAdmin = users2.some((u) => (u.email || "").toLowerCase() === "gtd.project.manager@gmail.com");
      if (!hasPMAdmin) {
        const rec = insert("users", {
          openId: "pm-" + Math.random().toString(36).slice(2),
          name: "Project Manager",
          email: "gtd.project.manager@gmail.com",
          role: "admin",
          loginMethod: "dev",
          lastSignedIn: /* @__PURE__ */ new Date()
        });
        try {
          insert("userPermissions", {
            userId: rec.id,
            permissionsJson: JSON.stringify({
              clients: true,
              projects: true,
              invoices: true,
              forms: true,
              accounting: true,
              hr: true,
              attachments: true,
              settings: true,
              dashboard: true,
              search: true
            }),
            updatedAt: /* @__PURE__ */ new Date()
          });
        } catch {
        }
      }
    }
  } catch {
  }
  registerOAuthRoutes(app);
  app.get("/fatore.HTML", (req, res) => {
    try {
      const possiblePaths = [
        path2.resolve(process.cwd(), "fatore.HTML"),
        path2.resolve(__dirname, "../../fatore.HTML"),
        path2.resolve(__dirname, "../../../fatore.HTML"),
        path2.resolve(__dirname, "../../dist/public/fatore.HTML")
      ];
      let filePath2 = "";
      for (const p of possiblePaths) {
        if (fs2.existsSync(p)) {
          filePath2 = p;
          break;
        }
      }
      if (!filePath2) {
        console.error("[fatore.HTML] File not found in any of:", possiblePaths);
        res.status(404).send("fatore.HTML not found");
        return;
      }
      let html = fs2.readFileSync(filePath2, "utf-8");
      html = html.replace(/src=["']data:image[^"']+["']/gi, 'src=""').replace(/url\\(data:image[^)]+\\)/gi, "none").replace(/url\\(['"]data:image[^'"]+['"]\\)/gi, "none");
      const settingsItems = list("companySettings");
      const getSetting = (k, d) => {
        const f = settingsItems.find((it) => it.settingKey === k);
        const v = f?.settingValue;
        return typeof v === "string" && v ? v : d;
      };
      const injectLogo = getSetting("invoiceInjectLogo", "true") === "true";
      const injectBarcode = getSetting("invoiceInjectBarcode", "true") === "true";
      const logoUrl = getSetting("companyLogoUrl", "/logo.png");
      const barcodeUrl = getSetting("companyBarcodeUrl", "/barcode.jpg");
      html = html.replace(
        /<div[^>]+class=["']logo-placeholder["'][^>]*>[\s\S]*?<\/div>/i,
        injectLogo ? `<div class="logo-placeholder"><img src="${logoUrl}" alt="Logo" style="max-height:100px;object-fit:contain"/></div>` : `<div class="logo-placeholder"></div>`
      ).replace(
        /<div[^>]+class=["']barcode-placeholder["'][^>]*>[\s\S]*?<\/div>/i,
        injectBarcode ? `<div class="barcode-placeholder"><img src="${barcodeUrl}" alt="Barcode" style="max-height:100px;object-fit:contain"/></div>` : `<div class="barcode-placeholder"></div>`
      );
      res.type("html").send(html);
    } catch (err) {
      console.error("[fatore.HTML] Error:", err);
      res.status(500).send("failed to read fatore.HTML");
    }
  });
  app.get("/clinthope.raw.html", (req, res) => {
    try {
      const possiblePaths = [
        path2.resolve(process.cwd(), "clinthope.html"),
        path2.resolve(__dirname, "../../clinthope.html"),
        path2.resolve(__dirname, "../../../clinthope.html")
      ];
      let filePath2 = "";
      for (const p of possiblePaths) {
        if (fs2.existsSync(p)) {
          filePath2 = p;
          break;
        }
      }
      if (!filePath2) {
        console.error("[clinthope.html] File not found in any of:", possiblePaths);
        res.status(404).send("clinthope.html not found");
        return;
      }
      const html = fs2.readFileSync(filePath2, "utf-8");
      res.type("html").send(html);
    } catch (err) {
      console.error("[clinthope.raw.html] Error:", err);
      res.status(500).send("failed to read clinthope.html");
    }
  });
  app.get("/clinthope.html", (req, res) => {
    try {
      const possiblePaths = [
        path2.resolve(process.cwd(), "clinthope.html"),
        path2.resolve(__dirname, "../../clinthope.html"),
        path2.resolve(__dirname, "../../../clinthope.html")
      ];
      let filePath2 = "";
      for (const p of possiblePaths) {
        if (fs2.existsSync(p)) {
          filePath2 = p;
          break;
        }
      }
      if (!filePath2) {
        console.error("[clinthope.html] File not found in any of:", possiblePaths);
        res.status(404).send("clinthope.html not found");
        return;
      }
      let html = fs2.readFileSync(filePath2, "utf-8");
      html = html.replace(/src=["']data:image[^"']+["']/gi, 'src=""').replace(/url\\(data:image[^)]+\\)/gi, "none").replace(/url\\(['"]data:image[^'"]+['"]\\)/gi, "none");
      const logo = `<div class="logo-wrapper" style="display:flex;justify-content:center;align-items:center;padding:8px 0"><img src="/logo.png" alt="Logo" style="max-height:80px;object-fit:contain"/></div>`;
      html = html.replace(/<div[^>]+class=["']header["'][^>]*>/i, (m) => `${m}${logo}`);
      res.type("html").send(html);
    } catch (err) {
      console.error("[clinthope.html] Error:", err);
      res.status(500).send("failed to read clinthope.html");
    }
  });
  app.get("/reports.export.csv", async (req, res) => {
    try {
      const ctx = await createContext({ req, res });
      const caller = appRouter.createCaller(ctx);
      const from = req.query.from ? new Date(String(req.query.from)) : new Date((/* @__PURE__ */ new Date()).getFullYear(), 0, 1);
      const to = req.query.to ? new Date(String(req.query.to)) : /* @__PURE__ */ new Date();
      const clientId = req.query.clientId ? Number(req.query.clientId) : void 0;
      const projectId = req.query.projectId ? Number(req.query.projectId) : void 0;
      const invoiceStatus = req.query.invoiceStatus ? String(req.query.invoiceStatus) : void 0;
      const purchaseStatus = req.query.purchaseStatus ? String(req.query.purchaseStatus) : void 0;
      const expenseStatus = req.query.expenseStatus ? String(req.query.expenseStatus) : void 0;
      const installmentStatus = req.query.installmentStatus ? String(req.query.installmentStatus) : void 0;
      const ts = await caller.reports.timeseries({
        from,
        to,
        granularity: "month",
        clientId,
        projectId,
        invoiceStatus,
        purchaseStatus,
        expenseStatus,
        installmentStatus
      });
      const rows = [["date", "invoices", "installments", "expenses", "net"]];
      (ts || []).forEach((r) => rows.push([r.dateKey, String(r.invoices), String(r.installments), String(r.expenses), String(r.net)]));
      const content = rows.map((r) => r.join(",")).join("\n");
      const bomContent = "\uFEFF" + content;
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="reports-${Date.now()}.csv"`);
      res.status(200).send(bomContent);
    } catch {
      res.status(500).send("failed to export csv");
    }
  });
  app.get("/reports.breakdown.csv", async (req, res) => {
    try {
      const ctx = await createContext({ req, res });
      const caller = appRouter.createCaller(ctx);
      const from = req.query.from ? new Date(String(req.query.from)) : new Date((/* @__PURE__ */ new Date()).getFullYear(), 0, 1);
      const to = req.query.to ? new Date(String(req.query.to)) : /* @__PURE__ */ new Date();
      const clientId = req.query.clientId ? Number(req.query.clientId) : void 0;
      const projectId = req.query.projectId ? Number(req.query.projectId) : void 0;
      const inv = Array.isArray(req.query.invoiceStatuses) ? req.query.invoiceStatuses : req.query.invoiceStatuses ? [String(req.query.invoiceStatuses)] : ["draft", "sent", "paid", "cancelled"];
      const pur = Array.isArray(req.query.purchaseStatuses) ? req.query.purchaseStatuses : req.query.purchaseStatuses ? [String(req.query.purchaseStatuses)] : ["pending", "completed", "cancelled"];
      const exp = Array.isArray(req.query.expenseStatuses) ? req.query.expenseStatuses : req.query.expenseStatuses ? [String(req.query.expenseStatuses)] : ["active", "cancelled"];
      const inst = Array.isArray(req.query.installmentStatuses) ? req.query.installmentStatuses : req.query.installmentStatuses ? [String(req.query.installmentStatuses)] : ["pending", "paid", "overdue", "cancelled"];
      const breakdown = await caller.reports.timeseriesBreakdown({
        from,
        to,
        granularity: "month",
        clientId,
        projectId,
        invoiceStatuses: inv,
        purchaseStatuses: pur,
        expenseStatuses: exp,
        installmentStatuses: inst
      });
      const statuses = [
        ...inv.map((s) => `inv:${s}`),
        ...pur.map((s) => `pur:${s}`),
        ...exp.map((s) => `exp:${s}`),
        ...inst.map((s) => `inst:${s}`)
      ];
      const header = ["date", ...statuses];
      const rows = [header];
      (breakdown || []).forEach((r) => {
        const row = [r.dateKey];
        statuses.forEach((h) => {
          const [group, name] = h.split(":");
          const map = group === "inv" ? r.invoices : group === "pur" ? r.purchases : group === "exp" ? r.expenses : r.installments || {};
          const val = (map || {})[name] || 0;
          row.push(String(val));
        });
        rows.push(row);
      });
      const content = rows.map((r) => r.join(",")).join("\n");
      const bomContent = "\uFEFF" + content;
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="reports-breakdown-${Date.now()}.csv"`);
      res.status(200).send(bomContent);
    } catch {
      res.status(500).send("failed to export breakdown csv");
    }
  });
  app.get("/reports.print.html", async (req, res) => {
    try {
      const ctx = await createContext({ req, res });
      const caller = appRouter.createCaller(ctx);
      const from = req.query.from ? new Date(String(req.query.from)) : new Date((/* @__PURE__ */ new Date()).getFullYear(), 0, 1);
      const to = req.query.to ? new Date(String(req.query.to)) : /* @__PURE__ */ new Date();
      const clientId = req.query.clientId ? Number(req.query.clientId) : void 0;
      const projectId = req.query.projectId ? Number(req.query.projectId) : void 0;
      const invoiceStatus = req.query.invoiceStatus ? String(req.query.invoiceStatus) : void 0;
      const purchaseStatus = req.query.purchaseStatus ? String(req.query.purchaseStatus) : void 0;
      const expenseStatus = req.query.expenseStatus ? String(req.query.expenseStatus) : void 0;
      const installmentStatus = req.query.installmentStatus ? String(req.query.installmentStatus) : void 0;
      const summary = await caller.reports.summary({
        from,
        to,
        clientId,
        projectId,
        invoiceStatus,
        purchaseStatus,
        expenseStatus,
        installmentStatus
      });
      const ts = await caller.reports.timeseries({
        from,
        to,
        granularity: "month",
        clientId,
        projectId,
        invoiceStatus,
        purchaseStatus,
        expenseStatus,
        installmentStatus
      });
      const html = `
        <!DOCTYPE html><html><head><meta charset="utf-8"><title>Reports</title>
        <style>
          body{font-family:system-ui,-apple-system,Segoe UI,Roboto; padding:24px}
          .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
          .card{border:1px solid #ddd;border-radius:8px;padding:12px}
          table{border-collapse:collapse;width:100%;margin-top:16px}
          th,td{border:1px solid #ddd;padding:6px;text-align:right}
          h1,h2{margin:8px 0}
        </style></head>
        <body>
          <h1>\u0627\u0644\u062A\u0642\u0627\u0631\u064A\u0631</h1>
          <div class="grid">
            <div class="card"><div>\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0641\u0648\u0627\u062A\u064A\u0631</div><h2>${summary?.invoicesTotal ?? 0}</h2></div>
            <div class="card"><div>\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0623\u0642\u0633\u0627\u0637</div><h2>${summary?.installmentsTotal ?? 0}</h2></div>
            <div class="card"><div>\u0625\u062C\u0645\u0627\u0644\u064A \u0627\u0644\u0645\u0635\u0631\u0648\u0641\u0627\u062A</div><h2>${summary?.expensesTotal ?? 0}</h2></div>
            <div class="card"><div>\u0627\u0644\u0635\u0627\u0641\u064A</div><h2>${summary?.net ?? 0}</h2></div>
          </div>
          <h2>\u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0632\u0645\u0646\u064A\u0629</h2>
          <table>
            <thead><tr><th>\u0627\u0644\u062A\u0627\u0631\u064A\u062E</th><th>\u0627\u0644\u0625\u064A\u0631\u0627\u062F\u0627\u062A</th><th>\u0627\u0644\u0623\u0642\u0633\u0627\u0637</th><th>\u0627\u0644\u0645\u0635\u0631\u0648\u0641\u0627\u062A</th><th>\u0627\u0644\u0635\u0627\u0641\u064A</th></tr></thead>
            <tbody>
              ${(ts || []).map((r) => "<tr><td>" + r.dateKey + "</td><td>" + r.invoices + "</td><td>" + r.installments + "</td><td>" + r.expenses + "</td><td>" + r.net + "</td></tr>").join("")}
            </tbody>
          </table>
          <script>
            function ready(){ try { window.focus(); setTimeout(function(){ window.print(); }, 200); } catch {} }
            if (document.readyState === 'complete') ready(); else window.onload = ready;
          </script>
        </body></html>
      `;
      res.type("html").send(html);
    } catch {
      res.status(500).send("failed to render report html");
    }
  });
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  return app;
}

// server/_core/index.ts
async function startServer() {
  const app = createApp();
  const server = createServer(app);
  if (false) {
    const { setupVite } = await null;
    await setupVite(app, server);
  } else {
    const { serveStatic: serveStatic2 } = await Promise.resolve().then(() => (init_vite_prod(), vite_prod_exports));
    serveStatic2(app);
  }
  const port = parseInt(process.env.PORT || "3000", 10);
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on port ${port} (NODE_ENV=${"production"})`);
  });
}
startServer().catch(console.error);
